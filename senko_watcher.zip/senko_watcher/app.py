# app.py  --  Senko Watcher
# Main entry point.  Orchestrates full startup and shutdown.
#
# Startup order:
#   1.  Ensure data directories
#   2.  Init logger + event log
#   3.  Load config
#   4.  Load playlists into AppState
#   5.  Run offline detection (compare history vs. local folders)
#   6.  Start download worker
#   7.  Start watcher thread
#   8.  Create tkinter root (always hidden first)
#   9.  Build MainWindow
#   10. Start tray icon
#   11. Transition BOOTING -> RUNNING
#   12. Show or hide window depending on start_minimized setting
#   13. Enter main loop
#
# Shutdown:
#   RUNNING/PAUSED -> SHUTTING_DOWN -> stop threads -> STOPPED -> destroy root

import os
import sys
import tkinter as tk

# Ensure project root is importable
_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)

import app_state
import lifecycle_manager
import services.logger as log
import services.event_logger as ev
import services.config_manager as config
import core.state_manager as sm
import core.watcher as watcher
import core.downloader as downloader
import core.offline_detector as od


def _ensure_dirs():
    for sub in ("data", "data/logs", "downloads"):
        os.makedirs(os.path.join(_BASE, sub), exist_ok=True)


# ── Global refs (used by shutdown callbacks) ──────────────────────────────────
_root_ref = None
_tray_ref = None


def _build_tray(main_win):
    from ui.tray_manager import TrayManager

    def on_show():
        if _root_ref:
            _root_ref.after(0, main_win.show)

    def on_pause_resume():
        lc = app_state.get("lifecycle")
        if lc == "PAUSED":
            sm.resume()
        elif lc == "RUNNING":
            sm.pause()

    tray = TrayManager(
        on_show_window  = on_show,
        on_pause_resume = on_pause_resume,
        on_check_now    = sm.check_now,
        on_quit         = _quit_from_tray,
    )
    tray.start()
    return tray


def _quit_from_tray():
    if _root_ref:
        _root_ref.after(0, _root_ref.quit)


def _graceful_shutdown():
    log.info("Shutdown started.")
    ev.emit("APP_SHUTDOWN")

    # Transition lifecycle
    lc = lifecycle_manager.current()
    if lc not in ("SHUTTING_DOWN", "STOPPED"):
        try:
            lifecycle_manager.transition("SHUTTING_DOWN")
        except lifecycle_manager.LifecycleError:
            pass

    watcher.stop()
    log.info("Watcher stopped.")

    if _tray_ref:
        try:
            _tray_ref.stop()
        except Exception:
            pass

    downloader.stop()
    log.info("Downloader stopped.")

    try:
        lifecycle_manager.transition("STOPPED")
    except lifecycle_manager.LifecycleError:
        pass

    ev.emit("APP_STOPPED")
    log.info("Shutdown complete.")


def main():
    global _root_ref, _tray_ref

    # 1. Directories
    _ensure_dirs()

    # 2. Init logger & event log
    log.info("=" * 60)
    log.info("Senko Watcher starting.")
    ev.emit("APP_STARTED")

    # 3. Load config
    cfg = config.load()
    start_minimized = cfg.get("start_minimized", True)
    log.info(f"Config loaded.  start_minimized={start_minimized}")

    # 4. Load playlists into AppState
    sm.load_playlists_into_state()

    # 5. Offline detection -- run before workers start
    log.info("Running offline detection...")
    try:
        pending = od.run_startup_detection()
        od.update_state_with_offline(pending)
        total_pending = sum(len(v) for v in pending.values())
        if total_pending:
            log.info(f"Offline detection: {total_pending} songs pending.")
            ev.emit("OFFLINE_DETECTION_COMPLETE", {"total_pending": total_pending})
    except Exception as exc:
        log.error(f"Offline detection failed: {exc}")

    # 6. Start download worker
    downloader.start()

    # 7. Start watcher
    watcher.start()

    # 8. Create tkinter root -- always hidden first
    root = tk.Tk()
    _root_ref = root
    root.withdraw()   # Always start hidden -- tray icon decides when to show

    # Suppress taskbar button when hidden
    # (Windows only: keeps window out of taskbar while withdrawn)
    try:
        root.attributes("-toolwindow", False)
        root.attributes("-alpha", 1.0)
    except Exception:
        pass

    # 9. Build main window
    from ui.main_window import MainWindow
    main_win = MainWindow(root, on_quit=_quit_from_tray)

    # 10. Start tray icon
    _tray_ref = _build_tray(main_win)

    # 11. Transition to RUNNING
    lifecycle_manager.transition("RUNNING")
    app_state.set_value("status_message", "Running. Watching playlists.")
    log.info("Senko Watcher is RUNNING.")
    ev.emit("APP_RUNNING")

    # 12. Show or stay hidden
    if not start_minimized:
        root.deiconify()
        main_win.show()
    else:
        log.info("Starting minimized to tray.")
        # Stay withdrawn -- user opens via tray

    # 13. Main loop
    try:
        root.mainloop()
    except KeyboardInterrupt:
        pass

    # 14. Shutdown
    _graceful_shutdown()


if __name__ == "__main__":
    main()
