# ui/main_window.py  --  Senko Watcher
# Main window with warm amber/dark fox-spirit theme.
# Polls AppState every 500ms.  UI never mutates state directly.
# Features:
#   - Offline-new detection banner
#   - Per-playlist last_checked display
#   - Global progress indicator
#   - Auto-download badge per playlist

import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import app_state
import lifecycle_manager
import core.state_manager as sm
import services.config_manager as config
import services.startup_manager as startup
from ui.playlist_window import PlaylistWindow

# ── Palette ───────────────────────────────────────────────────────────────────
BG       = "#0d0b0a"
BG2      = "#1a1510"
BG3      = "#261f17"
BG4      = "#32291c"
AMBER    = "#f5a623"
AMBER_DK = "#c47e10"
CORAL    = "#e8523a"
TEAL     = "#2ebfa5"
FG       = "#f0e8d8"
FG2      = "#8a7e6e"
FG3      = "#5a4e40"
GREEN    = "#7bc67e"
YELLOW   = "#ffd166"
ORANGE   = "#f5a623"
BLUE_SEL = "#1a3a5c"

FONT_APP  = ("Segoe UI Semibold", 18, "bold")
FONT_HEAD = ("Segoe UI", 11, "bold")
FONT_L    = ("Segoe UI", 10)
FONT_S    = ("Segoe UI", 9)
FONT_BTN  = ("Segoe UI", 10, "bold")
FONT_BIG  = ("Segoe UI", 30, "bold")
FONT_MONO = ("Consolas", 8)

REFRESH_MS = 500


class MainWindow:
    def __init__(self, root: tk.Tk, on_quit):
        self._root      = root
        self._on_quit   = on_quit
        self._prev_pl   = {}
        self._refresh_job = None

        self._configure_root()
        self._apply_styles()
        self._build_ui()
        self._schedule_refresh()

    # ── Root ──────────────────────────────────────────────────────────────────

    def _configure_root(self):
        self._root.title("Senko Watcher")
        self._root.configure(bg=BG)
        self._root.minsize(820, 580)
        self._root.geometry("1020x700")
        self._root.update_idletasks()
        sw, sh = self._root.winfo_screenwidth(), self._root.winfo_screenheight()
        self._root.geometry(f"1020x700+{(sw-1020)//2}+{(sh-700)//2}")
        self._root.protocol("WM_DELETE_WINDOW", self._hide_to_tray)
        
        # Set window icon (appears in taskbar)
        try:
            import os
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            icon_path = os.path.join(base_dir, "assets", "window_icon.ico")
            if os.path.exists(icon_path):
                self._root.iconbitmap(icon_path)
        except Exception:
            pass  # Continue without icon if it fails

    def _apply_styles(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("Treeview",
            background=BG2, foreground=FG, fieldbackground=BG2,
            rowheight=34, font=FONT_L)
        s.configure("Treeview.Heading",
            background=BG3, foreground=AMBER, font=("Segoe UI", 9, "bold"))
        s.map("Treeview",
            background=[("selected", BLUE_SEL)],
            foreground=[("selected", "#aad4f5")])
        s.configure("Vertical.TScrollbar",
            background=BG3, troughcolor=BG, bordercolor=BG, arrowcolor=FG2)
        s.configure("Amber.Horizontal.TProgressbar",
            troughcolor=BG3, background=AMBER,
            bordercolor=BG2, lightcolor=AMBER, darkcolor=AMBER_DK)

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        # ── App header ─────────────────────────────────────────────────────
        hdr = tk.Frame(self._root, bg=BG2, pady=0)
        hdr.pack(fill=tk.X)

        left_hdr = tk.Frame(hdr, bg=BG2, pady=12)
        left_hdr.pack(side=tk.LEFT, fill=tk.Y)

        # Fox emoji-like label using unicode
        tk.Label(left_hdr, text="  Senko Watcher",
                 bg=BG2, fg=AMBER, font=FONT_APP).pack(side=tk.LEFT, anchor="w")

        self._lbl_lifecycle = tk.Label(
            left_hdr, text="BOOTING", bg=BG3, fg=FG2,
            font=FONT_S, padx=10, pady=3, relief=tk.FLAT,
        )
        self._lbl_lifecycle.pack(side=tk.LEFT, padx=12)

        # Settings button
        tk.Button(
            hdr, text="Settings", command=self._open_settings,
            bg=BG3, fg=FG2, font=FONT_S, relief=tk.FLAT, padx=12, pady=6,
        ).pack(side=tk.RIGHT, padx=12, pady=10)

        # ── Offline-new banner (hidden until needed) ────────────────────────
        self._banner = tk.Frame(self._root, bg="#2a1a00", pady=8)
        self._lbl_banner = tk.Label(
            self._banner,
            text="",
            bg="#2a1a00", fg=YELLOW,
            font=FONT_L, anchor="w", padx=14,
        )
        self._lbl_banner.pack(side=tk.LEFT, fill=tk.X, expand=True)
        tk.Button(
            self._banner, text="Download All Pending",
            command=self._download_all_pending,
            bg=AMBER, fg=BG, font=FONT_BTN, relief=tk.FLAT, padx=12, pady=3, cursor="hand2",
        ).pack(side=tk.RIGHT, padx=10)
        # Banner is packed dynamically

        # ── Stat cards ─────────────────────────────────────────────────────
        stats = tk.Frame(self._root, bg=BG, pady=10)
        stats.pack(fill=tk.X, padx=14)

        self._card_new     = self._stat_card(stats, "0", "New Songs",  CORAL)
        self._card_pending = self._stat_card(stats, "0", "Pending",    AMBER)
        self._card_queue   = self._stat_card(stats, "0", "In Queue",   TEAL)
        self._card_lists   = self._stat_card(stats, "0", "Playlists",  FG2)

        # ── Download progress bar ───────────────────────────────────────────
        dl_frame = tk.Frame(self._root, bg=BG2, pady=7)
        dl_frame.pack(fill=tk.X, padx=14)

        tk.Label(dl_frame, text="Downloading:", bg=BG2, fg=FG2, font=FONT_S).pack(side=tk.LEFT, padx=(4,6))
        self._lbl_dl_title = tk.Label(
            dl_frame, text="Idle", bg=BG2, fg=FG2, font=FONT_S, anchor="w",
        )
        self._lbl_dl_title.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._progress_var = tk.DoubleVar(value=0)
        self._progressbar  = ttk.Progressbar(
            dl_frame, variable=self._progress_var,
            maximum=100, length=220, mode="determinate",
            style="Amber.Horizontal.TProgressbar",
        )
        self._progressbar.pack(side=tk.RIGHT, padx=(0, 12))
        self._lbl_pct = tk.Label(dl_frame, text="", bg=BG2, fg=AMBER, font=FONT_S, width=5)
        self._lbl_pct.pack(side=tk.RIGHT, padx=(0, 4))

        # ── Control bar ─────────────────────────────────────────────────────
        ctrl = tk.Frame(self._root, bg=BG3, pady=9)
        ctrl.pack(fill=tk.X, padx=14)

        self._btn_add = tk.Button(
            ctrl, text="+ Add Playlist",
            command=self._add_playlist,
            bg=AMBER, fg=BG, font=FONT_BTN, relief=tk.FLAT, padx=16, pady=7, cursor="hand2",
        )
        self._btn_add.pack(side=tk.LEFT, padx=(0, 8))

        self._btn_check = tk.Button(
            ctrl, text="Check Now",
            command=self._check_now,
            bg=BG4, fg=FG, font=FONT_BTN, relief=tk.FLAT, padx=14, pady=7, cursor="hand2",
        )
        self._btn_check.pack(side=tk.LEFT, padx=4)

        self._btn_pause = tk.Button(
            ctrl, text="Pause",
            command=self._toggle_pause,
            bg=BG4, fg=YELLOW, font=FONT_BTN, relief=tk.FLAT, padx=14, pady=7, cursor="hand2",
        )
        self._btn_pause.pack(side=tk.LEFT, padx=4)

        self._btn_realtime = tk.Button(
            ctrl, text="Real-Time: OFF",
            command=self._toggle_realtime,
            bg=BG4, fg=FG2, font=FONT_BTN, relief=tk.FLAT, padx=14, pady=7, cursor="hand2",
        )
        self._btn_realtime.pack(side=tk.LEFT, padx=4)

        self._btn_rm = tk.Button(
            ctrl, text="Remove Playlist",
            command=self._remove_playlist,
            bg=BG4, fg=CORAL, font=FONT_BTN, relief=tk.FLAT, padx=14, pady=7, cursor="hand2",
        )
        self._btn_rm.pack(side=tk.RIGHT)

        # ── Playlist table ──────────────────────────────────────────────────
        tbl = tk.Frame(self._root, bg=BG)
        tbl.pack(fill=tk.BOTH, expand=True, padx=14, pady=(6, 0))

        cols = ("name", "format", "auto_dl", "new", "pending", "total", "last_checked", "folder")
        self._tree = ttk.Treeview(tbl, columns=cols, show="headings", selectmode="browse")
        col_defs = [
            ("name",        "Playlist",      280, tk.W),
            ("format",      "Fmt",            50, tk.CENTER),
            ("auto_dl",     "Auto DL",        70, tk.CENTER),
            ("new",         "New",            55, tk.CENTER),
            ("pending",     "Pending",        65, tk.CENTER),
            ("total",       "Total",          55, tk.CENTER),
            ("last_checked","Last Checked",  160, tk.CENTER),
            ("folder",      "Folder",        200, tk.W),
        ]
        for col, head, w, anch in col_defs:
            self._tree.heading(col, text=head)
            self._tree.column(col, width=w, anchor=anch, minwidth=30)

        vsb = ttk.Scrollbar(tbl, orient=tk.VERTICAL, command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._tree.pack(fill=tk.BOTH, expand=True)

        self._tree.tag_configure("has_new",   foreground=YELLOW, font=FONT_HEAD)
        self._tree.tag_configure("normal",    foreground=FG)
        self._tree.tag_configure("pending",   foreground=AMBER)
        self._tree.tag_configure("inactive",  foreground=FG3)

        self._tree.bind("<Double-1>", self._on_dbl_click)
        self._tree.bind("<Button-3>", self._on_right_click)   # context menu

        # Context menu
        self._ctx_menu = tk.Menu(self._root, tearoff=0, bg=BG3, fg=FG,
                                  activebackground=BLUE_SEL, activeforeground=FG,
                                  font=FONT_S)
        self._ctx_menu.add_command(label="Open Playlist Window",  command=self._ctx_open)
        self._ctx_menu.add_command(label="Change Download Folder", command=self._ctx_change_folder)
        self._ctx_menu.add_command(label="Toggle Auto-Download",   command=self._ctx_toggle_auto)
        self._ctx_menu.add_separator()
        self._ctx_menu.add_command(label="Sync History",           command=self._ctx_sync)
        self._ctx_menu.add_command(label="Clear New Counter",      command=self._ctx_clear_new)
        self._ctx_menu.add_separator()
        self._ctx_menu.add_command(label="Remove Playlist",        command=self._remove_playlist)

        # ── Status bar ──────────────────────────────────────────────────────
        self._statusbar = tk.Label(
            self._root, text="", bg=BG3, fg=FG2,
            font=FONT_MONO, anchor="w", padx=10, pady=4,
        )
        self._statusbar.pack(fill=tk.X, side=tk.BOTTOM)

    def _stat_card(self, parent, value, label, color):
        f = tk.Frame(parent, bg=BG2, padx=22, pady=8)
        f.pack(side=tk.LEFT, padx=(0, 10))
        lv = tk.Label(f, text=value, bg=BG2, fg=color, font=FONT_BIG)
        lv.pack()
        lk = tk.Label(f, text=label, bg=BG2, fg=FG2, font=FONT_S)
        lk.pack()
        return {"val": lv, "lbl": lk, "color": color}

    # ── Refresh cycle ─────────────────────────────────────────────────────────

    def _schedule_refresh(self):
        self._refresh_job = self._root.after(REFRESH_MS, self._refresh)

    def _refresh(self):
        try:
            state = app_state.get_snapshot()
            self._sync_ui(state)
        except Exception:
            pass
        if not lifecycle_manager.is_shutting_down():
            self._schedule_refresh()

    def _sync_ui(self, state: dict):
        lc = state.get("lifecycle", "BOOTING")
        lc_colors = {
            "BOOTING":       (BG3, FG2),
            "RUNNING":       (GREEN, BG),
            "PAUSED":        (YELLOW, BG),
            "SHUTTING_DOWN": (ORANGE, BG),
            "STOPPED":       (CORAL, FG),
        }
        lc_bg, lc_fg = lc_colors.get(lc, (BG3, FG2))
        self._lbl_lifecycle.configure(text=lc, bg=lc_bg, fg=lc_fg)
        self._btn_pause.configure(text="Resume" if lc == "PAUSED" else "Pause")

        # Real-time button
        rt = state.get("realtime_mode", False)
        rt_interval = state.get("realtime_interval", 60)
        if rt:
            self._btn_realtime.configure(
                text=f"Real-Time: ON ({rt_interval}s)", bg="#1a3a1a", fg=GREEN,
            )
        else:
            self._btn_realtime.configure(text="Real-Time: OFF", bg=BG4, fg=FG2)

        # Stats
        self._card_new["val"].configure(text=str(state.get("total_new_songs", 0)))
        self._card_pending["val"].configure(text=str(state.get("total_offline_new", 0)))
        self._card_queue["val"].configure(text=str(state.get("download_queue_size", 0)))
        self._card_lists["val"].configure(text=str(len(state.get("playlists", {}))))

        # Progress bar
        active = state.get("active_download")
        progress = state.get("download_progress") or {}
        if active and progress:
            pct = progress.get(active, 0)
            self._progress_var.set(pct)
            self._lbl_pct.configure(text=f"{pct:.0f}%")
            dl_title = state.get("currently_downloading", "")
            self._lbl_dl_title.configure(text=dl_title[:65], fg=TEAL)
        else:
            self._progress_var.set(0)
            self._lbl_pct.configure(text="")
            q = state.get("download_queue_size", 0)
            if q:
                self._lbl_dl_title.configure(text=f"{q} in queue...", fg=YELLOW)
            else:
                self._lbl_dl_title.configure(text="Idle", fg=FG2)

        # Offline banner
        total_offline = state.get("total_offline_new", 0)
        if total_offline > 0:
            self._lbl_banner.configure(
                text=f"  {total_offline} song(s) not yet downloaded (detected while offline)."
            )
            if not self._banner.winfo_ismapped():
                self._banner.pack(fill=tk.X, before=self._root.winfo_children()[2])
        else:
            if self._banner.winfo_ismapped():
                self._banner.pack_forget()

        # Status bar
        self._statusbar.configure(text=state.get("status_message", ""))

        # Playlist table (soft refresh)
        playlists = state.get("playlists", {})
        if playlists != self._prev_pl:
            self._rebuild_table(playlists)
            self._prev_pl = dict(playlists)

    def _rebuild_table(self, playlists: dict):
        sel = self._tree.selection()
        sel_id = sel[0] if sel else None
        self._tree.delete(*self._tree.get_children())

        for pid, p in playlists.items():
            new_cnt     = p.get("new_count", 0)
            pending_cnt = p.get("offline_new_count", 0)
            auto_dl     = p.get("auto_download", True)
            folder      = p.get("download_folder", "")

            if new_cnt:
                tag = "has_new"
                new_lbl = f"  {new_cnt} NEW"
            elif pending_cnt:
                tag = "pending"
                new_lbl = "-"
            else:
                tag = "normal"
                new_lbl = "-"

            pend_lbl = str(pending_cnt) if pending_cnt else "-"
            auto_lbl = "Yes" if auto_dl else "No"

            # Shorten folder for display
            folder_display = folder
            if len(folder_display) > 28:
                folder_display = "..." + folder_display[-25:]

            self._tree.insert("", tk.END, iid=pid, tags=(tag,), values=(
                p.get("name", pid),
                p.get("format", "mp3").upper(),
                auto_lbl,
                new_lbl,
                pend_lbl,
                str(p.get("video_count", 0)),
                p.get("last_checked", "Never"),
                folder_display,
            ))

        if sel_id and self._tree.exists(sel_id):
            self._tree.selection_set(sel_id)

    # ── User actions ──────────────────────────────────────────────────────────

    def _on_dbl_click(self, event):
        item = self._tree.identify_row(event.y)
        if item:
            PlaylistWindow.open_for(self._root, item)
            sm.clear_new_count(item)

    def _on_right_click(self, event):
        row = self._tree.identify_row(event.y)
        if row:
            self._tree.selection_set(row)
            self._ctx_menu.post(event.x_root, event.y_root)

    def _selected_pid(self) -> str:
        sel = self._tree.selection()
        return sel[0] if sel else ""

    def _ctx_open(self):
        pid = self._selected_pid()
        if pid:
            PlaylistWindow.open_for(self._root, pid)

    def _ctx_change_folder(self):
        pid = self._selected_pid()
        if not pid:
            return
        import services.config_manager as _cfg
        pcfg = _cfg.get_playlist(pid)
        cur  = pcfg.get("download_folder", "")
        initial = cur if cur and os.path.isdir(cur) else os.path.expanduser("~")
        chosen = filedialog.askdirectory(title="Selecione a pasta de download",
                                          initialdir=initial, parent=self._root)
        if chosen:
            sm.update_playlist_folder(pid, chosen)

    def _ctx_toggle_auto(self):
        pid = self._selected_pid()
        if not pid:
            return
        pl  = (app_state.get("playlists") or {}).get(pid, {})
        sm.update_auto_download(pid, not pl.get("auto_download", True))

    def _ctx_sync(self):
        pid = self._selected_pid()
        if pid:
            sm.sync_history(pid)

    def _ctx_clear_new(self):
        pid = self._selected_pid()
        if pid:
            sm.clear_new_count(pid)

    def _add_playlist(self):
        dlg = AddPlaylistDialog(self._root)
        self._root.wait_window(dlg)
        r = getattr(dlg, "result", None)
        if r:
            try:
                pid = sm.add_playlist(
                    name=r["name"], url=r["url"], fmt=r["format"],
                    auto_download=r["auto_download"], download_folder=r["folder"],
                )
            except ValueError as exc:
                messagebox.showerror("Erro ao adicionar playlist", str(exc), parent=self._root)
                return
            # Sync history immediately so songs appear right away
            app_state.set_value("status_message", f"Sincronizando historico de '{r['name']}'...")
            sm.sync_history(pid)

    def _remove_playlist(self):
        pid = self._selected_pid()
        if not pid:
            messagebox.showinfo("Nothing selected", "Select a playlist to remove.", parent=self._root)
            return
        name = (app_state.get("playlists") or {}).get(pid, {}).get("name", pid)
        if messagebox.askyesno("Confirm", f"Remove '{name}'?\n(History is kept.)", parent=self._root):
            sm.remove_playlist(pid)

    def _toggle_pause(self):
        if lifecycle_manager.is_paused():
            sm.resume()
        else:
            sm.pause()

    def _toggle_realtime(self):
        current = app_state.get("realtime_mode", False)
        if not current:
            # Ask for interval
            dlg = RealtimeDialog(self._root)
            self._root.wait_window(dlg)
            r = getattr(dlg, "result", None)
            if r is None:
                return
            sm.set_realtime_mode(True, r)
        else:
            sm.set_realtime_mode(False)

    def _check_now(self):
        sm.check_now()

    def _download_all_pending(self):
        """Queue all offline-pending songs across all playlists."""
        offline = app_state.get("offline_new") or {}
        total   = 0
        errors  = []
        for pid, vids in offline.items():
            pl  = (app_state.get("playlists") or {}).get(pid, {})
            fmt = pl.get("format", "mp3")
            try:
                q = sm.queue_videos_now(pid, vids, fmt)
                total += q
            except ValueError as exc:
                errors.append(str(exc))

        # Clear offline counts
        app_state.set_value("offline_new", {})
        app_state.set_value("total_offline_new", 0)
        playlists = app_state.get("playlists") or {}
        for pid in playlists:
            playlists[pid]["offline_new_count"] = 0
        app_state.set_value("playlists", playlists)

        msg = f"Enviadas {total} musica(s) para download."
        if errors:
            msg += f"  Erros: {'; '.join(errors)}"
        self._statusbar.configure(text=msg)

    def _open_settings(self):
        SettingsDialog(self._root)

    def _hide_to_tray(self):
        self._root.withdraw()

    def show(self):
        self._root.deiconify()
        self._root.lift()
        self._root.focus_force()


# ── Add Playlist Dialog ───────────────────────────────────────────────────────

class AddPlaylistDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.title("Adicionar Playlist")
        self.configure(bg=BG2)
        self.resizable(False, False)
        self.geometry("560x440")
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - 560) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - 440) // 2
        self.geometry(f"560x440+{x}+{y}")

        self._fmt_var    = tk.StringVar(value="mp3")
        self._auto_var   = tk.BooleanVar(value=True)
        self._folder_var = tk.StringVar(value="")
        self._build()
        self.transient(parent)
        self.grab_set()
        self.bind("<Escape>", lambda e: self.destroy())

    def _build(self):
        tk.Label(self, text="Adicionar Nova Playlist",
                 bg=BG2, fg=AMBER, font=FONT_HEAD).pack(padx=20, pady=(16, 10))

        for lbl_text, attr in [("Nome da Playlist:", "_ent_name"),
                                ("URL do YouTube:",   "_ent_url")]:
            f = tk.Frame(self, bg=BG2)
            f.pack(fill=tk.X, padx=20, pady=3)
            tk.Label(f, text=lbl_text, bg=BG2, fg=FG2, font=FONT_S,
                     anchor="w", width=18).pack(side=tk.LEFT)
            ent = tk.Entry(f, bg=BG3, fg=FG, insertbackground=AMBER,
                           font=FONT_L, relief=tk.FLAT, bd=5)
            ent.pack(side=tk.LEFT, fill=tk.X, expand=True)
            setattr(self, attr, ent)

        # Folder (mandatory -- shown in red label)
        ff = tk.Frame(self, bg=BG2)
        ff.pack(fill=tk.X, padx=20, pady=3)
        tk.Label(ff, text="Pasta de Download *:", bg=BG2, fg=CORAL, font=FONT_S,
                 anchor="w", width=18).pack(side=tk.LEFT)
        tk.Entry(ff, textvariable=self._folder_var,
                 bg=BG3, fg=TEAL, font=FONT_MONO, relief=tk.FLAT, bd=4,
                 state="readonly").pack(side=tk.LEFT, fill=tk.X, expand=True)
        tk.Button(ff, text="Escolher Pasta", command=self._browse,
                  bg=AMBER, fg=BG, font=FONT_S, relief=tk.FLAT, padx=8, pady=2,
                  cursor="hand2").pack(side=tk.LEFT, padx=(6, 0))

        # Format selector (4 options in 2x2 grid)
        fmt_lf = tk.LabelFrame(self, text=" Formato de Download ",
                                bg=BG2, fg=FG2, font=FONT_S, bd=1, pady=6, padx=10)
        fmt_lf.pack(fill=tk.X, padx=20, pady=(8, 2))
        formats = [
            ("mp3",        "MP3  (somente audio)"),
            ("mp4",        "MP4  (audio + video)"),
            ("webm-audio", "WebM (somente audio)"),
            ("webm-video", "WebM (audio + video)"),
        ]
        for i, (key, label) in enumerate(formats):
            tk.Radiobutton(
                fmt_lf, text=label, variable=self._fmt_var, value=key,
                bg=BG2, fg=FG, selectcolor=BG3, activebackground=BG2,
                activeforeground=AMBER, font=FONT_S,
            ).grid(row=i // 2, column=i % 2, sticky="w", padx=14, pady=2)

        # Auto-download toggle
        tk.Checkbutton(self, text="Baixar automaticamente novas musicas detectadas",
                       variable=self._auto_var,
                       bg=BG2, fg=FG, selectcolor=BG3,
                       activebackground=BG2, activeforeground=AMBER,
                       font=FONT_S).pack(anchor="w", padx=26, pady=6)

        # Buttons
        btns = tk.Frame(self, bg=BG2)
        btns.pack(padx=20, pady=(4, 16))
        tk.Button(btns, text="Cancelar", command=self.destroy,
                  bg=BG3, fg=FG2, font=FONT_BTN, relief=tk.FLAT,
                  padx=14, pady=7).pack(side=tk.RIGHT, padx=(6, 0))
        tk.Button(btns, text="Adicionar Playlist", command=self._submit,
                  bg=AMBER, fg=BG, font=FONT_BTN, relief=tk.FLAT,
                  padx=18, pady=7, cursor="hand2").pack(side=tk.RIGHT)

    def _browse(self):
        chosen = filedialog.askdirectory(
            title="Pasta de Download", initialdir=os.path.expanduser("~"), parent=self
        )
        if chosen:
            self._folder_var.set(chosen)

    def _submit(self):
        name   = self._ent_name.get().strip()
        url    = self._ent_url.get().strip()
        folder = self._folder_var.get().strip()
        if not name:
            messagebox.showwarning("Campo obrigatorio", "Informe o nome da playlist.", parent=self)
            return
        if not url:
            messagebox.showwarning("Campo obrigatorio", "Informe a URL da playlist.", parent=self)
            return
        if "youtube.com" not in url and "youtu.be" not in url:
            messagebox.showwarning("URL invalida", "Deve ser uma URL do YouTube.", parent=self)
            return
        if not folder:
            messagebox.showwarning(
                "Pasta obrigatoria",
                "Clique em Escolher Pasta antes de continuar. Cada playlist precisa de uma pasta propria.",
                parent=self,
            )
            return
        self.result = {
            "name":          name,
            "url":           url,
            "format":        self._fmt_var.get(),
            "auto_download": self._auto_var.get(),
            "folder":        folder,
        }
        self.destroy()


# ── Settings Dialog ───────────────────────────────────────────────────────────

class SettingsDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Settings")
        self.configure(bg=BG2)
        self.resizable(False, False)
        self.geometry("460x420")
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - 460) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - 420) // 2
        self.geometry(f"460x420+{x}+{y}")

        cfg = config.load()
        self._interval  = tk.IntVar(value=cfg.get("check_interval_seconds", 1800) // 60)
        self._notif     = tk.BooleanVar(value=cfg.get("notifications_enabled", True))
        self._startup   = tk.BooleanVar(value=startup.is_enabled())
        self._minimized = tk.BooleanVar(value=cfg.get("start_minimized", True))

        self._build()
        self.transient(parent)
        self.grab_set()
        self.bind("<Escape>", lambda e: self.destroy())

    def _build(self):
        pad = {"padx": 22, "pady": 6}
        tk.Label(self, text="Settings", bg=BG2, fg=AMBER, font=FONT_HEAD).pack(padx=22, pady=(18, 12))

        # Interval
        r = tk.Frame(self, bg=BG2)
        r.pack(fill=tk.X, **pad)
        tk.Label(r, text="Check interval (minutes):", bg=BG2, fg=FG2, font=FONT_L).pack(side=tk.LEFT)
        tk.Spinbox(r, from_=5, to=1440, textvariable=self._interval, width=7,
                   bg=BG3, fg=FG, font=FONT_L, relief=tk.FLAT).pack(side=tk.RIGHT)

        # Note: pasta de download e configurada por playlist

        # Checkboxes
        for var, lbl_text in [
            (self._notif,     "Enable desktop notifications"),
            (self._startup,   "Start with Windows"),
            (self._minimized, "Start minimized to tray"),
        ]:
            tk.Checkbutton(self, variable=var, text=lbl_text,
                           bg=BG2, fg=FG, selectcolor=BG3,
                           activebackground=BG2, activeforeground=AMBER,
                           font=FONT_L).pack(anchor="w", **pad)

        tk.Button(self, text="Save Settings", command=self._save,
                  bg=AMBER, fg=BG, font=FONT_BTN, relief=tk.FLAT, padx=20, pady=8,
                  cursor="hand2").pack(pady=(18, 10))

    def _save(self):
        cfg_updates = {
            "check_interval_seconds": self._interval.get() * 60,
            "notifications_enabled":  self._notif.get(),
            "start_with_windows":     self._startup.get(),
            "start_minimized":        self._minimized.get(),
        }
        for k, v in cfg_updates.items():
            config.set_key(k, v)
        app_state.update({
            "notifications_enabled": self._notif.get(),
            "startup_minimized":     self._minimized.get(),
        })
        if self._startup.get():
            startup.enable()
        else:
            startup.disable()
        self.destroy()


# ── Realtime Dialog ───────────────────────────────────────────────────────────

class RealtimeDialog(tk.Toplevel):
    """Ask the user for the real-time check interval."""

    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.title("Real-Time Monitoring")
        self.configure(bg=BG2)
        self.resizable(False, False)
        self.geometry("380x240")
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - 380) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - 240) // 2
        self.geometry(f"380x240+{x}+{y}")
        self._interval = tk.IntVar(value=60)
        self._build()
        self.transient(parent)
        self.grab_set()
        self.bind("<Escape>", lambda e: self.destroy())

    def _build(self):
        tk.Label(self, text="Real-Time Monitoring",
                 bg=BG2, fg=AMBER, font=FONT_HEAD).pack(padx=20, pady=(18, 6))
        tk.Label(self,
                 text="O app verificara as playlists continuamente.\nNovos videos serao baixados imediatamente.",
                 bg=BG2, fg=FG2, font=FONT_S, justify=tk.CENTER).pack(padx=20, pady=4)

        row = tk.Frame(self, bg=BG2)
        row.pack(padx=20, pady=10)
        tk.Label(row, text="Verificar a cada (segundos):", bg=BG2, fg=FG, font=FONT_L).pack(side=tk.LEFT)
        opts = [30, 60, 120, 300]
        self._sel = tk.StringVar(value="60")
        mb = tk.OptionMenu(row, self._sel, *[str(o) for o in opts])
        mb.configure(bg=BG3, fg=AMBER, activebackground=BG4, activeforeground=AMBER,
                     highlightthickness=0, font=FONT_L, relief=tk.FLAT)
        mb.pack(side=tk.LEFT, padx=8)

        btns = tk.Frame(self, bg=BG2)
        btns.pack(padx=20, pady=(10, 18))
        tk.Button(btns, text="Cancelar", command=self.destroy,
                  bg=BG3, fg=FG2, font=FONT_BTN, relief=tk.FLAT, padx=12, pady=6).pack(side=tk.RIGHT, padx=(6,0))
        tk.Button(btns, text="Ativar", command=self._submit,
                  bg=GREEN, fg=BG, font=FONT_BTN, relief=tk.FLAT, padx=16, pady=6,
                  cursor="hand2").pack(side=tk.RIGHT)

    def _submit(self):
        try:
            self.result = int(self._sel.get())
        except ValueError:
            self.result = 60
        self.destroy()
