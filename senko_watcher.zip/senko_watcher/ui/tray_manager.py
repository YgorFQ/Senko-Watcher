# ui/tray_manager.py  --  Senko Watcher
# System tray icon.  Runs in daemon thread.
# App starts hidden -- only tray icon shows.

import threading
import app_state
import services.logger as log

APP_NAME = "Senko Watcher"


def _make_icon_image():
    """Load tray icon from assets/tray_icon.png, with fallback."""
    try:
        from PIL import Image
        import os
        # Try to load icon from file
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        icon_path = os.path.join(base_dir, "assets", "tray_icon.png")
        
        if os.path.exists(icon_path):
            return Image.open(icon_path)
        else:
            # Fallback: simple colored square
            img = Image.new("RGBA", (64, 64), (245, 166, 35, 255))
            return img
    except ImportError:
        return None
    except Exception:
        try:
            from PIL import Image
            img = Image.new("RGBA", (64, 64), (245, 166, 35, 255))
            return img
        except ImportError:
            return None


class TrayManager:
    def __init__(self, on_show_window, on_pause_resume, on_check_now, on_quit):
        self._on_show   = on_show_window
        self._on_pr     = on_pause_resume
        self._on_check  = on_check_now
        self._on_quit   = on_quit
        self._tray      = None
        self._thread    = None

    def _build_menu(self):
        try:
            import pystray
        except ImportError:
            return None

        lc        = app_state.get("lifecycle", "")
        is_paused = lc == "PAUSED"
        new_cnt   = app_state.get("total_new_songs", 0)
        offline   = app_state.get("total_offline_new", 0)
        queue_sz  = app_state.get("download_queue_size", 0)
        active_dl = app_state.get("currently_downloading", "")

        lbl_pr    = "Resume Monitoring" if is_paused else "Pause Monitoring"

        # Status labels
        def info_item(text):
            return pystray.MenuItem(text, None, enabled=False)

        items = [
            pystray.MenuItem(APP_NAME, self._on_show, default=True),
            pystray.Menu.SEPARATOR,
        ]
        if active_dl:
            items.append(info_item(f"Downloading: {active_dl[:40]}"))
        if queue_sz:
            items.append(info_item(f"Queue: {queue_sz}"))
        if new_cnt:
            items.append(info_item(f"{new_cnt} new song(s) detected"))
        if offline:
            items.append(info_item(f"{offline} pending (offline)"))
        items.append(pystray.Menu.SEPARATOR)
        items += [
            pystray.MenuItem("Open Window",    lambda i, m: self._on_show()),
            pystray.MenuItem(lbl_pr,           lambda i, m: self._on_pr()),
            pystray.MenuItem("Check Now",      lambda i, m: self._on_check()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit",           lambda i, m: self._on_quit()),
        ]
        return pystray.Menu(*items)

    def _run(self):
        try:
            import pystray
        except ImportError:
            log.warning("pystray not installed -- tray unavailable.")
            return

        img = _make_icon_image()
        if img is None:
            log.warning("Pillow not installed -- no tray icon.")
            return

        self._tray = pystray.Icon(
            "SenkoWatcher", img, APP_NAME, menu=self._build_menu()
        )
        try:
            self._tray.run()
        except Exception as exc:
            log.error(f"Tray error: {exc}")

    def start(self):
        self._thread = threading.Thread(target=self._run, name="TrayThread", daemon=True)
        self._thread.start()

    def update_menu(self):
        if self._tray:
            try:
                self._tray.menu = self._build_menu()
                self._tray.update_menu()
            except Exception:
                pass

    def update_title(self, title: str):
        if self._tray:
            try:
                self._tray.title = title
            except Exception:
                pass

    def stop(self):
        if self._tray:
            try:
                self._tray.stop()
            except Exception:
                pass
