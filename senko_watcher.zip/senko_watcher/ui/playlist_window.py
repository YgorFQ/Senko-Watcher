# ui/playlist_window.py  --  Senko Watcher
# Playlist detail window.
# - Treeview with blue row highlight on click/selection
# - All 4 format options: mp3, mp4, webm-audio, webm-video
# - Per-playlist: folder, format, auto-download toggle
# - Progress bar for active download
# - Download Now / Sync History / Open Folder

import os
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import app_state
import core.history_manager as history
import core.state_manager as sm
import services.config_manager as config

# ── Palette ───────────────────────────────────────────────────────────────────
BG       = "#0d0b0a"
BG2      = "#1a1510"
BG3      = "#261f17"
BG4      = "#32291c"
AMBER    = "#f5a623"
AMBER2   = "#d4891e"
CORAL    = "#e8523a"
TEAL     = "#2ebfa5"
FG       = "#f0e8d8"
FG2      = "#8a7e6e"
SEL_BG   = "#163050"
SEL_FG   = "#aad4f5"
GREEN    = "#7bc67e"
YELLOW   = "#ffd166"

FONT_H   = ("Segoe UI", 13, "bold")
FONT_L   = ("Segoe UI", 10)
FONT_S   = ("Segoe UI", 9)
FONT_B   = ("Segoe UI", 10, "bold")
FONT_M   = ("Consolas", 9)

REFRESH_MS = 500

# All supported formats
FORMATS = [
    ("mp3",        "MP3 (audio)"),
    ("mp4",        "MP4 (video)"),
    ("webm-audio", "WebM (audio only)"),
    ("webm-video", "WebM (audio + video)"),
]


class PlaylistWindow(tk.Toplevel):
    _open: dict = {}

    @classmethod
    def open_for(cls, parent, playlist_id: str):
        if playlist_id in cls._open:
            w = cls._open[playlist_id]
            try:
                w.lift()
                w.focus_force()
                return
            except tk.TclError:
                pass
        cls._open[playlist_id] = cls(parent, playlist_id)

    def __init__(self, parent, playlist_id: str):
        super().__init__(parent)
        self._pid         = playlist_id
        self._selected    = set()       # set of selected video_ids
        self._all_rows    = []          # list of (video_id, vdata)
        self._fmt_var     = tk.StringVar(value="mp3")
        self._auto_var    = tk.BooleanVar(value=True)
        self._search_var  = tk.StringVar()
        self._refresh_job = None

        self._init_window()
        self._build_ui()
        self._load_settings()
        self._load_videos()
        self._schedule_refresh()

        self.protocol("WM_DELETE_WINDOW", self._close)
        self.bind("<Escape>", lambda e: self._close())

    # ── Window init ───────────────────────────────────────────────────────────

    def _init_window(self):
        pl = (app_state.get("playlists") or {}).get(self._pid, {})
        self._name = pl.get("name", self._pid)
        self.title(f"Senko Watcher  --  {self._name}")
        self.configure(bg=BG)
        self.geometry("940x680")
        self.minsize(720, 500)
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"940x680+{(sw-940)//2}+{(sh-680)//2}")

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        # ── Header ──────────────────────────────────────────────────────────
        hdr = tk.Frame(self, bg=BG2, pady=10)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text=self._name, bg=BG2, fg=AMBER, font=FONT_H,
                 anchor="w", padx=14).pack(side=tk.LEFT)

        # ── Settings panel ───────────────────────────────────────────────────
        settings = tk.LabelFrame(
            self, text=" Configuracoes da Playlist ", bg=BG3, fg=AMBER2,
            font=FONT_S, bd=1, relief=tk.GROOVE, pady=8, padx=10,
        )
        settings.pack(fill=tk.X, padx=10, pady=(6, 2))

        # Row 1: folder
        row1 = tk.Frame(settings, bg=BG3)
        row1.pack(fill=tk.X, pady=3)
        tk.Label(row1, text="Pasta de Download:", bg=BG3, fg=FG2, font=FONT_S,
                 width=18, anchor="w").pack(side=tk.LEFT)
        self._lbl_folder = tk.Label(
            row1, text="...", bg=BG4, fg=TEAL, font=FONT_M,
            anchor="w", padx=6, relief=tk.FLAT,
        )
        self._lbl_folder.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        tk.Button(row1, text="Alterar Pasta", command=self._change_folder,
                  bg=BG2, fg=AMBER, font=FONT_S, relief=tk.FLAT, padx=8, pady=3,
                  cursor="hand2").pack(side=tk.LEFT, padx=(0, 4))
        tk.Button(row1, text="Abrir Pasta", command=self._open_folder,
                  bg=BG2, fg=TEAL, font=FONT_S, relief=tk.FLAT, padx=8, pady=3,
                  cursor="hand2").pack(side=tk.LEFT)

        # Row 2: format + auto-download
        row2 = tk.Frame(settings, bg=BG3)
        row2.pack(fill=tk.X, pady=3)
        tk.Label(row2, text="Formato:", bg=BG3, fg=FG2, font=FONT_S,
                 width=18, anchor="w").pack(side=tk.LEFT)
        for key, label in FORMATS:
            tk.Radiobutton(
                row2, text=label, variable=self._fmt_var, value=key,
                bg=BG3, fg=FG, selectcolor=BG, activebackground=BG3,
                activeforeground=AMBER, font=FONT_S,
                command=self._on_format_change,
            ).pack(side=tk.LEFT, padx=(0, 10))

        # Row 3: auto-download toggle
        row3 = tk.Frame(settings, bg=BG3)
        row3.pack(fill=tk.X, pady=3)
        tk.Label(row3, text="Auto-download:", bg=BG3, fg=FG2, font=FONT_S,
                 width=18, anchor="w").pack(side=tk.LEFT)
        tk.Checkbutton(
            row3, text="Baixar automaticamente novas musicas detectadas",
            variable=self._auto_var, command=self._on_auto_change,
            bg=BG3, fg=FG, selectcolor=BG, activebackground=BG3,
            activeforeground=AMBER, font=FONT_S,
        ).pack(side=tk.LEFT)

        # ── Toolbar ──────────────────────────────────────────────────────────
        tb = tk.Frame(self, bg=BG2, pady=6)
        tb.pack(fill=tk.X, padx=10)

        self._btn_dl = tk.Button(
            tb, text="  Download Now  ",
            command=self._download_now,
            bg=CORAL, fg="white", font=FONT_B, relief=tk.FLAT,
            padx=14, pady=5, cursor="hand2",
        )
        self._btn_dl.pack(side=tk.LEFT, padx=(0, 8))

        tk.Button(tb, text="Selecionar Tudo", command=self._select_all,
                  bg=BG4, fg=FG2, font=FONT_S, relief=tk.FLAT, padx=8, pady=5,
                  cursor="hand2").pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="Desmarcar Tudo", command=self._deselect_all,
                  bg=BG4, fg=FG2, font=FONT_S, relief=tk.FLAT, padx=8, pady=5,
                  cursor="hand2").pack(side=tk.LEFT, padx=2)
        self._lbl_sel = tk.Label(tb, text="0 selecionados", bg=BG2, fg=FG2, font=FONT_S)
        self._lbl_sel.pack(side=tk.LEFT, padx=10)

        tk.Button(tb, text="Sincronizar Historico", command=self._sync,
                  bg=BG4, fg=YELLOW, font=FONT_S, relief=tk.FLAT, padx=8, pady=5,
                  cursor="hand2").pack(side=tk.RIGHT)

        # ── Search ───────────────────────────────────────────────────────────
        srch = tk.Frame(self, bg=BG, pady=4)
        srch.pack(fill=tk.X, padx=10)
        tk.Label(srch, text="Buscar:", bg=BG, fg=FG2, font=FONT_S).pack(side=tk.LEFT)
        self._search_var.trace_add("write", lambda *a: self._render_tree())
        tk.Entry(srch, textvariable=self._search_var,
                 bg=BG2, fg=FG, insertbackground=AMBER,
                 font=FONT_S, relief=tk.FLAT, bd=5, width=44,
                 ).pack(side=tk.LEFT, padx=6, fill=tk.X, expand=True)

        # ── Treeview ─────────────────────────────────────────────────────────
        tree_frame = tk.Frame(self, bg=BG)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=4)

        style = ttk.Style()
        style.configure("PL.Treeview",
            background=BG2, foreground=FG, fieldbackground=BG2,
            rowheight=26, font=FONT_S)
        style.configure("PL.Treeview.Heading",
            background=BG3, foreground=AMBER, font=("Segoe UI", 9, "bold"))
        # Disable the default tkinter blue selection -- we manage it with tags
        style.map("PL.Treeview",
            background=[("selected", BG2)],
            foreground=[("selected", FG)])

        cols = ("chk", "title", "first_seen", "status")
        self._tree = ttk.Treeview(
            tree_frame, columns=cols, show="headings",
            selectmode="browse", style="PL.Treeview",
        )
        col_defs = [
            ("chk",        " ",           34, tk.CENTER),
            ("title",      "Titulo",      560, tk.W),
            ("first_seen", "Adicionado",  150, tk.CENTER),
            ("status",     "Status",       90, tk.CENTER),
        ]
        for col, head, w, anch in col_defs:
            self._tree.heading(col, text=head)
            self._tree.column(col, width=w, anchor=anch, minwidth=20)

        vsb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._tree.pack(fill=tk.BOTH, expand=True)

        # Row tags
        self._tree.tag_configure("sel_even",  background=SEL_BG,  foreground=SEL_FG)
        self._tree.tag_configure("sel_odd",   background=SEL_BG,  foreground=SEL_FG)
        self._tree.tag_configure("done_even", background=BG2,     foreground=FG2)
        self._tree.tag_configure("done_odd",  background=BG3,     foreground=FG2)
        self._tree.tag_configure("new_even",  background=BG2,     foreground=YELLOW)
        self._tree.tag_configure("new_odd",   background=BG3,     foreground=YELLOW)
        self._tree.tag_configure("norm_even", background=BG2,     foreground=FG)
        self._tree.tag_configure("norm_odd",  background=BG3,     foreground=FG)

        self._tree.bind("<ButtonRelease-1>", self._on_row_click)
        self._tree.bind("<Double-1>",        self._on_row_dbl)

        # ── Progress bar ─────────────────────────────────────────────────────
        prog_row = tk.Frame(self, bg=BG2, pady=5)
        prog_row.pack(fill=tk.X, padx=10)
        tk.Label(prog_row, text="Download:", bg=BG2, fg=FG2, font=FONT_S).pack(side=tk.LEFT, padx=(4,6))
        self._prog_var = tk.DoubleVar(value=0)
        self._progbar  = ttk.Progressbar(
            prog_row, variable=self._prog_var, maximum=100,
            length=300, mode="determinate",
        )
        style.configure("Amber.Horizontal.TProgressbar",
            troughcolor=BG3, background=AMBER,
            bordercolor=BG2, lightcolor=AMBER, darkcolor=AMBER2)
        self._progbar.configure(style="Amber.Horizontal.TProgressbar")
        self._progbar.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._lbl_pct = tk.Label(prog_row, text="", bg=BG2, fg=AMBER, font=FONT_S, width=6)
        self._lbl_pct.pack(side=tk.LEFT, padx=4)

        # ── Status bar ────────────────────────────────────────────────────────
        self._statusbar = tk.Label(
            self, text="Pronto", bg=BG3, fg=FG2, font=FONT_S,
            anchor="w", padx=12, pady=4,
        )
        self._statusbar.pack(fill=tk.X, side=tk.BOTTOM)

    # ── Load settings from config ─────────────────────────────────────────────

    def _load_settings(self):
        pcfg = config.get_playlist(self._pid)
        self._fmt_var.set(pcfg.get("format", "mp3"))
        self._auto_var.set(pcfg.get("auto_download", True))
        folder = pcfg.get("download_folder", "")
        self._lbl_folder.configure(text=folder or "(nao definida)")

    # ── Video loading ─────────────────────────────────────────────────────────

    def _load_videos(self):
        self._selected.clear()
        self._all_rows.clear()
        videos = history.get_playlist_videos(self._pid)
        if not videos:
            self._statusbar.configure(
                text="Nenhum video no historico. Use 'Sincronizar Historico'."
            )
            self._render_tree()
            return
        # Sort by first_seen descending (most recent first)
        self._all_rows = sorted(
            videos.items(),
            key=lambda kv: kv[1].get("first_seen", ""),
            reverse=True,
        )
        self._render_tree()
        self._update_sel_label()

    def _render_tree(self):
        query = self._search_var.get().strip().lower()
        # Remember scroll position
        try:
            yview = self._tree.yview()
        except Exception:
            yview = (0.0, 1.0)

        for item in self._tree.get_children():
            self._tree.delete(item)

        visible = 0
        for i, (vid_id, vdata) in enumerate(self._all_rows):
            title = vdata.get("title", "")
            if query and query not in title.lower():
                continue

            is_sel  = vid_id in self._selected
            is_done = vdata.get("downloaded", False)
            parity  = "even" if visible % 2 == 0 else "odd"

            if is_sel:
                tag = f"sel_{parity}"
                chk = "[X]"
            elif is_done:
                tag = f"done_{parity}"
                chk = "[ ]"
            else:
                tag = f"norm_{parity}"
                chk = "[ ]"

            status_txt = "Baixado" if is_done else "Pendente"

            self._tree.insert(
                "", tk.END, iid=vid_id, tags=(tag,),
                values=(chk, title[:100], vdata.get("first_seen", ""), status_txt),
            )
            visible += 1

        self._statusbar.configure(text=f"{len(self._all_rows)} total  |  {visible} exibidos")
        # Restore scroll position
        try:
            self._tree.yview_moveto(yview[0])
        except Exception:
            pass

    # ── Periodic refresh ──────────────────────────────────────────────────────

    def _schedule_refresh(self):
        try:
            self._refresh_job = self.after(REFRESH_MS, self._tick)
        except tk.TclError:
            pass

    def _tick(self):
        try:
            self._update_progress()
            self._update_sel_label()
            # Reload settings in case changed from main window
            pcfg   = config.get_playlist(self._pid)
            folder = pcfg.get("download_folder", "")
            self._lbl_folder.configure(text=folder or "(nao definida)")
            self._schedule_refresh()
        except tk.TclError:
            pass

    def _update_progress(self):
        progress = app_state.get("download_progress") or {}
        active   = app_state.get("active_download")
        if active and progress:
            pct = progress.get(active, 0)
            self._prog_var.set(pct)
            self._lbl_pct.configure(text=f"{pct:.0f}%")
            dl_title = app_state.get("currently_downloading", "")
            self._statusbar.configure(text=f"Baixando: {dl_title[:60]}  {pct:.0f}%")
        else:
            self._prog_var.set(0)
            self._lbl_pct.configure(text="")

    # ── Row interaction ───────────────────────────────────────────────────────

    def _on_row_click(self, event):
        region = self._tree.identify("region", event.x, event.y)
        row    = self._tree.identify_row(event.y)
        if not row or region != "cell":
            return
        # Toggle selection
        if row in self._selected:
            self._selected.discard(row)
        else:
            self._selected.add(row)
        self._render_tree()
        self._update_sel_label()

    def _on_row_dbl(self, event):
        row = self._tree.identify_row(event.y)
        if not row:
            return
        videos = history.get_playlist_videos(self._pid)
        v = videos.get(row)
        if v:
            import webbrowser
            webbrowser.open(v.get("url", ""))

    def _update_sel_label(self):
        self._lbl_sel.configure(text=f"{len(self._selected)} selecionados")

    # ── Actions ───────────────────────────────────────────────────────────────

    def _download_now(self):
        if not self._selected:
            messagebox.showinfo(
                "Nenhum selecionado",
                "Clique nas linhas para selecionar as musicas antes de baixar.",
                parent=self,
            )
            return

        pcfg   = config.get_playlist(self._pid)
        folder = pcfg.get("download_folder", "").strip()
        if not folder:
            messagebox.showerror(
                "Pasta nao definida",
                "Defina a pasta de download desta playlist antes de baixar.\n"
                "Clique em 'Alterar Pasta' acima.",
                parent=self,
            )
            return

        fmt = self._fmt_var.get()
        try:
            queued = sm.queue_videos_now(self._pid, list(self._selected), fmt)
        except ValueError as exc:
            messagebox.showerror("Erro", str(exc), parent=self)
            return

        self._statusbar.configure(
            text=f"Enviadas {queued}/{len(self._selected)} para download [{fmt}] -> {folder}"
        )
        # Deselect after queuing
        self._selected.clear()
        self._render_tree()
        self._update_sel_label()

    def _select_all(self):
        self._selected = {vid_id for vid_id, _ in self._all_rows}
        self._render_tree()
        self._update_sel_label()

    def _deselect_all(self):
        self._selected.clear()
        self._render_tree()
        self._update_sel_label()

    def _sync(self):
        self._statusbar.configure(text="Sincronizando historico...")
        sm.sync_history(self._pid)
        self.after(4000, self._load_videos)

    def _on_format_change(self):
        fmt = self._fmt_var.get()
        sm.update_playlist_format(self._pid, fmt)
        self._statusbar.configure(text=f"Formato atualizado para: {fmt}")

    def _on_auto_change(self):
        enabled = self._auto_var.get()
        sm.update_auto_download(self._pid, enabled)
        self._statusbar.configure(
            text=f"Auto-download: {'ativado' if enabled else 'desativado'}"
        )

    def _change_folder(self):
        pcfg    = config.get_playlist(self._pid)
        cur     = pcfg.get("download_folder", "")
        initial = cur if cur and os.path.isdir(cur) else os.path.expanduser("~")
        chosen  = filedialog.askdirectory(
            title="Selecione a pasta de download", initialdir=initial, parent=self
        )
        if chosen:
            sm.update_playlist_folder(self._pid, chosen)
            self._lbl_folder.configure(text=chosen)
            self._statusbar.configure(text=f"Pasta atualizada: {chosen}")

    def _open_folder(self):
        pcfg   = config.get_playlist(self._pid)
        folder = pcfg.get("download_folder", "")
        if not folder or not os.path.isdir(folder):
            messagebox.showinfo(
                "Pasta nao encontrada",
                "A pasta nao existe ainda. Sera criada no primeiro download.",
                parent=self,
            )
            return
        try:
            os.startfile(folder)
        except AttributeError:
            import subprocess
            subprocess.Popen(["xdg-open", folder])

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def _close(self):
        PlaylistWindow._open.pop(self._pid, None)
        if self._refresh_job:
            try:
                self.after_cancel(self._refresh_job)
            except Exception:
                pass
        self.destroy()
