# 🤝 Guia de Contribuição - Senko Watcher

Obrigado por considerar contribuir com o Senko Watcher! 

---

## 📋 Índice

1. [Código de Conduta](#-código-de-conduta)
2. [Como Contribuir](#-como-contribuir)
3. [Reportando Bugs](#-reportando-bugs)
4. [Sugerindo Features](#-sugerindo-features)
5. [Processo de Pull Request](#-processo-de-pull-request)
6. [Guia de Estilo](#-guia-de-estilo)
7. [Estrutura do Projeto](#-estrutura-do-projeto)
8. [Ambiente de Desenvolvimento](#-ambiente-de-desenvolvimento)

---

## 📜 Código de Conduta

- Seja respeitoso e inclusivo
- Aceite críticas construtivas
- Foque no que é melhor para a comunidade
- Demonstre empatia com outros membros

---

## 🎯 Como Contribuir

Há várias formas de contribuir:

### 1. 🐛 Reportar Bugs
Encontrou um problema? Veja [Reportando Bugs](#-reportando-bugs)

### 2. 💡 Sugerir Features
Tem uma ideia? Veja [Sugerindo Features](#-sugerindo-features)

### 3. 📝 Melhorar Documentação
- Corrigir erros
- Adicionar exemplos
- Traduzir (inglês, espanhol, etc.)
- Escrever tutoriais

### 4. 🔧 Corrigir Bugs
Veja [issues abertas](https://github.com/seu-usuario/senko-watcher/issues) com label `bug`

### 5. ✨ Implementar Features
Veja [issues abertas](https://github.com/seu-usuario/senko-watcher/issues) com label `enhancement`

### 6. 🧪 Testar
- Teste em diferentes sistemas operacionais
- Teste com diferentes tipos de playlists
- Reporte problemas de performance

---

## 🐛 Reportando Bugs

### Antes de Reportar

1. ✅ Verifique se já não existe uma [issue similar](https://github.com/seu-usuario/senko-watcher/issues)
2. ✅ Teste com a versão mais recente
3. ✅ Leia [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

### Template de Bug Report

```markdown
**Descrição do Bug**
Uma descrição clara do que aconteceu.

**Como Reproduzir**
Passos para reproduzir:
1. Vá para '...'
2. Clique em '....'
3. Role até '....'
4. Veja o erro

**Comportamento Esperado**
O que deveria acontecer.

**Screenshots**
Se aplicável, adicione screenshots.

**Ambiente:**
 - OS: [ex: Windows 11]
 - Python: [ex: 3.11.5]
 - Versão: [ex: 1.0.0]

**Logs**
Últimas 50 linhas de `data/logs/senko_watcher.log`:
```
[Cole aqui]
```

**Informações Adicionais**
Qualquer outro contexto relevante.
```

---

## 💡 Sugerindo Features

### Template de Feature Request

```markdown
**A feature resolve um problema?**
Uma descrição clara do problema. Ex: "Sempre fico frustrado quando [...]"

**Solução Proposta**
Uma descrição clara do que você quer que aconteça.

**Alternativas Consideradas**
Outras soluções ou features que você considerou.

**Contexto Adicional**
Screenshots, mockups, exemplos de outros apps, etc.

**Complexidade Estimada**
 - [ ] Simples (poucas horas)
 - [ ] Média (alguns dias)
 - [ ] Complexa (semanas)
 - [ ] Não sei

**Disposto a Implementar?**
 - [ ] Sim, posso fazer um PR
 - [ ] Não, apenas sugerindo
 - [ ] Preciso de ajuda para implementar
```

---

## 🔄 Processo de Pull Request

### 1. Fork e Clone

```bash
# Fork no GitHub, então:
git clone https://github.com/SEU-USUARIO/senko-watcher.git
cd senko-watcher
```

### 2. Crie uma Branch

```bash
git checkout -b feature/minha-feature
# ou
git checkout -b bugfix/corrige-x
```

**Padrões de nome:**
- `feature/nome-da-feature` - Nova funcionalidade
- `bugfix/nome-do-bug` - Correção de bug
- `docs/o-que-foi-feito` - Documentação
- `refactor/o-que-foi-refatorado` - Refatoração
- `test/o-que-foi-testado` - Testes

### 3. Faça Suas Mudanças

- Escreva código claro
- Comente partes complexas
- Siga o [Guia de Estilo](#-guia-de-estilo)
- Teste suas mudanças

### 4. Commit

```bash
git add .
git commit -m "feat: adiciona suporte para X"
```

**Padrões de commit (Conventional Commits):**
- `feat:` - Nova funcionalidade
- `fix:` - Correção de bug
- `docs:` - Documentação
- `style:` - Formatação (não afeta código)
- `refactor:` - Refatoração
- `test:` - Adiciona/corrige testes
- `chore:` - Manutenção/outros

**Exemplos:**
```
feat: adiciona suporte para baixar shorts
fix: corrige download de vídeos privados
docs: atualiza README com instruções de instalação
refactor: reorganiza estrutura de pastas
```

### 5. Push e Pull Request

```bash
git push origin feature/minha-feature
```

Então abra um Pull Request no GitHub.

### Template de Pull Request

```markdown
**Descrição**
Breve descrição das mudanças.

**Tipo de Mudança**
- [ ] Bug fix
- [ ] Nova feature
- [ ] Breaking change
- [ ] Documentação

**Como foi testado?**
Descreva os testes que realizou.

**Checklist**
- [ ] Código segue o guia de estilo
- [ ] Comentei código complexo
- [ ] Atualizei documentação
- [ ] Não quebra funcionalidades existentes
- [ ] Testei em [Windows/Linux/Mac]

**Screenshots** (se aplicável)
```

---

## 📐 Guia de Estilo

### Python

**Seguimos PEP 8 com algumas adaptações:**

```python
# ✅ BOM
def download_video(url: str, format: str = "mp3") -> bool:
    """
    Download a video from YouTube.
    
    Args:
        url: YouTube video URL
        format: Output format (mp3, mp4, webm)
        
    Returns:
        True if successful, False otherwise
    """
    if not url:
        return False
    
    # Código aqui
    return True


# ❌ RUIM
def DownloadVideo(URL,FMT="mp3"):
    if not URL: return False
    #codigo aqui
    return True
```

**Convenções:**

1. **Imports**
   ```python
   # Ordem:
   # 1. Biblioteca padrão
   # 2. Bibliotecas externas
   # 3. Módulos locais
   
   import os
   import sys
   
   import yt_dlp
   from PIL import Image
   
   import app_state
   import services.logger as log
   ```

2. **Nomes**
   - Variáveis/funções: `snake_case`
   - Classes: `PascalCase`
   - Constantes: `UPPER_CASE`

3. **Docstrings**
   - Sempre documente funções públicas
   - Use formato Google ou NumPy

4. **Type Hints**
   - Use quando possível
   - Ajuda no debugging

5. **Comentários**
   ```python
   # ✅ BOM - explica o "porquê"
   # Aguarda 1 segundo para evitar rate limiting do YouTube
   time.sleep(1)
   
   # ❌ RUIM - explica o óbvio
   # Dorme por 1 segundo
   time.sleep(1)
   ```

### Interface (Tkinter)

```python
# Estrutura consistente
class MinhaJanela(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self._init_window()
        self._build_ui()
        self._bind_events()
    
    def _init_window(self):
        # Configuração da janela
        pass
    
    def _build_ui(self):
        # Construção da interface
        pass
    
    def _bind_events(self):
        # Vinculação de eventos
        pass
```

### Arquivos

**Estrutura de arquivo Python:**

```python
# comentário de cabeçalho
# Breve descrição do arquivo

# Imports
import ...

# Constantes
CONSTANT = valor

# Classes/Funções
def main():
    pass

# Entry point (apenas em scripts executáveis)
if __name__ == "__main__":
    main()
```

---

## 🏗️ Estrutura do Projeto

```
senko_watcher/
│
├── app.py                 # Entry point
├── app_state.py           # Estado global (thread-safe)
├── lifecycle_manager.py   # FSM do ciclo de vida
│
├── core/                  # Lógica de negócio
│   ├── downloader.py      # Worker de downloads
│   ├── watcher.py         # Monitor de playlists
│   ├── download_queue.py  # Fila thread-safe
│   ├── history_manager.py # Persistência de histórico
│   ├── offline_detector.py# Detecção offline
│   └── state_manager.py   # Comandos de alto nível
│
├── ui/                    # Interface gráfica
│   ├── main_window.py     # Janela principal
│   ├── playlist_window.py # Detalhes da playlist
│   └── tray_manager.py    # Ícone da bandeja
│
├── services/              # Serviços auxiliares
│   ├── config_manager.py  # Configuração JSON
│   ├── logger.py          # Logging
│   ├── event_logger.py    # Eventos
│   └── startup_manager.py # Registro Windows
│
├── assets/                # Recursos
│   ├── tray_icon.png
│   ├── window_icon.ico
│   └── senko.ico
│
└── data/                  # Dados (runtime)
    ├── config.json
    ├── history.json
    └── logs/
```

**Princípios:**

1. **Separação de Responsabilidades**
   - UI não acessa dados diretamente
   - UI chama `state_manager`, que coordena `core`
   - `core` módulos são independentes

2. **Thread Safety**
   - `app_state` é thread-safe (Lock)
   - `download_queue` usa Queue
   - Workers usam threading.Event

3. **Estado Global**
   - Apenas via `app_state`
   - Nunca mutação direta
   - Sempre use getters/setters

---

## 🛠️ Ambiente de Desenvolvimento

### Setup

```bash
# 1. Clone
git clone https://github.com/SEU-USUARIO/senko-watcher.git
cd senko-watcher

# 2. Crie venv (recomendado)
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 3. Instale dependências
pip install -r requirements.txt

# 4. Instale dev dependencies
pip install pylint black pytest
```

### Executar

```bash
python app.py
```

### Linting

```bash
# Check
pylint app.py core/ ui/ services/

# Format
black .
```

### Testes (TODO)

```bash
pytest tests/
```

---

## 🎯 Áreas que Precisam de Ajuda

### Prioridade Alta
- [ ] Testes automatizados (pytest)
- [ ] CI/CD (GitHub Actions)
- [ ] Suporte para mais plataformas (Vimeo, SoundCloud?)

### Prioridade Média
- [ ] Interface mais moderna (customtkinter?)
- [ ] Temas personalizáveis
- [ ] Localização (i18n)
- [ ] Mais opções de qualidade de vídeo

### Prioridade Baixa
- [ ] Versão CLI
- [ ] API REST para controle remoto
- [ ] Plugin system

---

## 📞 Contato

- **Issues:** [GitHub Issues](https://github.com/seu-usuario/senko-watcher/issues)
- **Discussions:** [GitHub Discussions](https://github.com/seu-usuario/senko-watcher/discussions)
- **Email:** seu-email@exemplo.com

---

## 🏆 Contribuidores

Obrigado a todos que contribuíram! 🦊

<!-- ALL-CONTRIBUTORS-LIST:START -->
<!-- TODO: adicionar lista de contribuidores -->
<!-- ALL-CONTRIBUTORS-LIST:END -->

---

**🦊 Obrigado por contribuir com o Senko Watcher!**
