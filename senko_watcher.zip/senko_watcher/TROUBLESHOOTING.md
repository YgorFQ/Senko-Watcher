# 🔧 Guia de Solução de Problemas - Senko Watcher

Este guia cobre os problemas mais comuns e suas soluções.

---

## 📋 Índice

1. [Problemas de Instalação](#problemas-de-instalação)
2. [Problemas com FFmpeg](#problemas-com-ffmpeg)
3. [Problemas de Download](#problemas-de-download)
4. [Problemas de Interface](#problemas-de-interface)
5. [Problemas de Performance](#problemas-de-performance)
6. [Logs e Diagnóstico](#logs-e-diagnóstico)

---

## 🔨 Problemas de Instalação

### ❌ "pip: command not found" ou "pip is not recognized"

**Causa:** Python não está no PATH ou pip não foi instalado.

**Solução:**
```bash
# Use python -m pip ao invés de pip:
python -m pip install -r requirements.txt

# Ou instale o pip:
python -m ensurepip --upgrade
```

### ❌ "ModuleNotFoundError: No module named 'yt_dlp'"

**Causa:** Dependências não instaladas corretamente.

**Solução:**
```bash
# Reinstale todas as dependências:
pip uninstall yt-dlp pystray Pillow plyer -y
pip install -r requirements.txt

# Ou individualmente:
pip install yt-dlp --upgrade
```

### ❌ Erro de permissão ao instalar

**Windows:**
```bash
pip install -r requirements.txt --user
```

**Linux/Mac:**
```bash
pip3 install -r requirements.txt --user
# ou
sudo pip3 install -r requirements.txt
```

---

## 🎬 Problemas com FFmpeg

### ❌ "FFmpeg not found" ou "ERROR: Postprocessing failed"

**Diagnóstico:** Verifique se FFmpeg está instalado:
```bash
ffmpeg -version
```

**Se não retornar a versão:**

#### Windows:
1. Baixe FFmpeg: https://www.gyan.dev/ffmpeg/builds/
2. Escolha "ffmpeg-release-essentials.zip"
3. Extraia para `C:\ffmpeg`
4. Adicione ao PATH:
   - Windows + R → `sysdm.cpl` → Enter
   - Aba "Avançado" → "Variáveis de Ambiente"
   - Em "Variáveis do sistema", clique em "Path" → "Editar"
   - "Novo" → Digite: `C:\ffmpeg\bin`
   - OK em tudo
5. **Reinicie o prompt de comando**
6. Teste: `ffmpeg -version`

#### Linux (Ubuntu/Debian):
```bash
sudo apt update
sudo apt install ffmpeg
ffmpeg -version
```

#### Linux (Fedora/RHEL):
```bash
sudo dnf install ffmpeg
ffmpeg -version
```

#### MacOS:
```bash
brew install ffmpeg
ffmpeg -version
```

### ❌ FFmpeg instalado mas app não encontra

**Solução:**
1. Reinicie o computador (para PATH atualizar)
2. Abra um **novo** terminal
3. Teste: `ffmpeg -version`
4. Inicie o app: `python app.py`

**Alternativa:** Use formatos WebM (não precisam de FFmpeg)

---

## ⬇️ Problemas de Download

### ❌ "No download folder configured"

**Causa:** Playlist sem pasta definida.

**Solução:**
1. Clique duplo na playlist
2. Clique "Alterar Pasta"
3. Escolha uma pasta válida
4. Tente baixar novamente

### ❌ Downloads ficam em 0% ou não iniciam

**Causa 1:** Fila cheia ou outro download em andamento.

**Solução:**
- Aguarde o download atual terminar
- Verifique a fila (ícone da bandeja mostra "Queue: X")

**Causa 2:** Vídeo indisponível ou playlist privada.

**Solução:**
1. Abra a URL da playlist no navegador
2. Verifique se está pública
3. Tente baixar um vídeo individual manualmente

**Causa 3:** Problemas de rede.

**Solução:**
- Verifique sua conexão
- Desative VPN temporariamente
- Tente novamente mais tarde

### ❌ "ERROR: Video unavailable"

**Causas possíveis:**
- Vídeo foi removido
- Vídeo está privado
- Restrição geográfica
- Vídeo age-restricted

**Solução:**
- Pule o vídeo (será marcado como falho)
- Remova-o manualmente da playlist do YouTube
- Use VPN se for restrição geográfica

### ❌ Download trava em 99%

**Causa:** FFmpeg não consegue fazer merge/conversão.

**Solução 1:** Use formato WebM
1. Clique duplo na playlist
2. Mude formato para "WebM (audio only)" ou "WebM (audio + video)"

**Solução 2:** Reinstale FFmpeg
```bash
# Windows: reinstale seguindo o guia acima

# Linux:
sudo apt remove ffmpeg
sudo apt install ffmpeg

# Teste:
ffmpeg -version
```

### ❌ Áudio e vídeo dessincronizados

**Causa:** Problema no merge do FFmpeg.

**Solução:**
1. Delete o arquivo corrompido
2. Baixe novamente
3. Se persistir, use formato WebM

### ❌ "HTTP Error 429: Too Many Requests"

**Causa:** YouTube bloqueou temporariamente por muitas requisições.

**Solução:**
- Aguarde 1-2 horas
- Reduza frequência de verificação (Settings → Real-time interval)
- Pause o monitoramento temporariamente

---

## 🖥️ Problemas de Interface

### ❌ Ícone não aparece na bandeja

**Causa 1:** pystray ou Pillow não instalados.

**Solução:**
```bash
pip install pystray Pillow --upgrade
```

**Causa 2:** Sistema operacional não suportado.

**Solução:**
- No Windows: Use Windows 10/11
- No Linux: Instale um ambiente desktop (GNOME, KDE, etc.)

### ❌ Janela não abre ao clicar no ícone

**Solução:**
1. Feche o app (botão direito → Quit)
2. Delete `data/config.json`
3. Inicie novamente: `python app.py`

### ❌ Interface está em inglês ou travada

**Solução:**
1. Force fechamento (Ctrl+C no terminal ou Task Manager)
2. Delete arquivos de cache:
   - Windows: `%TEMP%\senko_watcher`
   - Linux: `~/.cache/senko_watcher`
3. Reinicie o app

### ❌ Cores/temas estranhos

**Causa:** Problema com tkinter themes.

**Solução:**
Edite `ui/main_window.py` linha 74:
```python
# Troque:
s.theme_use("clam")

# Por:
s.theme_use("default")
```

---

## 🐌 Problemas de Performance

### ❌ App consumindo muita RAM

**Causa:** Muitas playlists ou histórico grande.

**Solução:**
1. Limite número de playlists (máximo 10-15)
2. Limpe histórico antigo:
   - Delete `data/history.json`
   - Clique "Sincronizar Histórico" em cada playlist

### ❌ Verificações muito lentas

**Solução:**
1. Desative Real-time mode
2. Use intervalo maior (5-10 minutos)
3. Verifique se tem muitas playlists

### ❌ Download muito lento

**Causa:** Limitação do YouTube ou rede lenta.

**Solução:**
- Use formato menor (MP3 ao invés de MP4)
- Pause outros downloads
- Verifique velocidade da internet

---

## 📝 Logs e Diagnóstico

### Onde ficam os logs?

```
senko_watcher/
└── data/
    └── logs/
        └── senko_watcher.log
```

### Como ler os logs?

Abra com bloco de notas ou:
```bash
# Ver últimas 50 linhas:
tail -n 50 data/logs/senko_watcher.log

# Ver em tempo real:
tail -f data/logs/senko_watcher.log
```

### Logs importantes:

**Sucesso:**
```
[INFO] Download [mp3] -> C:\Music | 'Nome da Música'
[INFO] DOWNLOAD_FINISHED
```

**Erro de FFmpeg:**
```
[ERROR] yt-dlp error: ffmpeg not found
[ERROR] Postprocessing failed
```

**Erro de rede:**
```
[ERROR] HTTP Error 403
[ERROR] Video unavailable
```

### Modo Debug

Para logs mais detalhados, edite `services/logger.py`:
```python
# Linha ~15, troque:
level=logging.INFO

# Por:
level=logging.DEBUG
```

---

## 🆘 Ainda com Problemas?

### Passo a Passo de Diagnóstico:

1. **Verifique Python:**
   ```bash
   python --version
   # Deve ser 3.8 ou superior
   ```

2. **Verifique dependências:**
   ```bash
   pip list | grep -E "yt-dlp|pystray|Pillow|plyer"
   ```

3. **Verifique FFmpeg (se usar MP3/MP4):**
   ```bash
   ffmpeg -version
   ```

4. **Teste básico:**
   ```bash
   python -c "import yt_dlp; print('OK')"
   ```

5. **Leia os logs:**
   ```bash
   cat data/logs/senko_watcher.log
   ```

6. **Teste yt-dlp diretamente:**
   ```bash
   yt-dlp --version
   yt-dlp "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
   ```

### Reportar Bug

Se nada funcionar, abra uma issue com:
1. Sistema operacional e versão
2. Versão do Python (`python --version`)
3. Conteúdo de `pip list`
4. Últimas 50 linhas do log
5. Passos para reproduzir o problema

---

## 💡 Dicas de Prevenção

### ✅ Faça backup regular

```bash
# Backup de configurações:
cp data/config.json data/config.json.backup
cp data/history.json data/history.json.backup
```

### ✅ Atualize regularmente

```bash
# Atualize yt-dlp (importante!):
pip install yt-dlp --upgrade

# Atualize tudo:
pip install -r requirements.txt --upgrade
```

### ✅ Use formatos WebM

Se tiver problemas com FFmpeg, sempre use WebM:
- Não precisa de conversão
- Mais rápido
- Menos propenso a erros

### ✅ Monitore o uso

- Não adicione 50+ playlists
- Limpe histórico antigo periodicamente
- Use pastas organizadas para downloads

---

**🦊 Boa sorte com o Senko Watcher!**

Dúvida não resolvida? Abra uma issue no GitHub!
