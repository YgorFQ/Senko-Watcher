# app_state.py  --  Senko Watcher
# Single Source of Truth.  All UI reads from here.  Core writes here.
# Thread-safe via RLock.
#
# New fields vs v1:
#   download_progress      : dict  { video_id: float 0-100 }
#   offline_new            : dict  { playlist_id: [video_id, ...] }
#   currently_downloading  : str   -- title being downloaded right now

import threading
import copy

_DEFAULTS = {
    # Lifecycle
    "lifecycle":              "BOOTING",

    # Playlists: { playlist_id: PlaylistEntry }
    # PlaylistEntry = {
    #   playlist_id, name, url, format, auto_download,
    #   download_folder, new_count, last_checked, video_count,
    #   offline_new_count
    # }
    "playlists":              {},

    # Download state
    "download_queue_size":    0,
    "active_download":        None,      # video_id
    "currently_downloading":  "",        # display title
    "download_progress":      {},        # { video_id: float 0-100 }

    # Songs detected while offline (not yet downloaded)
    "offline_new":            {},        # { playlist_id: [video_id, ...] }

    # Counters
    "total_new_songs":        0,
    "total_offline_new":      0,

    # Misc
    "last_check_time":        "",
    "notifications_enabled":  True,
    "status_message":         "Starting...",
    "startup_minimized":      True,
    "realtime_mode":          False,
    "realtime_interval":      60,
}

_lock  = threading.RLock()
_state = copy.deepcopy(_DEFAULTS)


def get(key, default=None):
    with _lock:
        return _state.get(key, default)


def set_value(key, value):
    with _lock:
        _state[key] = value


def update(updates: dict):
    with _lock:
        _state.update(updates)


def get_snapshot() -> dict:
    with _lock:
        return copy.deepcopy(_state)


def reset():
    with _lock:
        _state.clear()
        _state.update(copy.deepcopy(_DEFAULTS))
