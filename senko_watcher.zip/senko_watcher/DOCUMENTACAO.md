# 📚 Índice de Documentação - Senko Watcher

Bem-vindo ao **Senko Watcher**! Este índice te ajuda a encontrar rapidamente a informação que precisa.

---

## 🚀 Para Começar

### Novo por aqui?

1. **[INICIO_RAPIDO.md](INICIO_RAPIDO.md)** ⚡
   - Guia de 5 minutos
   - Instalação rápida
   - Primeira playlist
   - 📍 **Comece aqui!**

2. **[README.md](README.md)** 📖
   - Documentação completa
   - Todos os recursos
   - Configuração detalhada
   - Para quem quer entender tudo

---

## 🎯 Por Objetivo

### Quero instalar o projeto
→ **[INICIO_RAPIDO.md](INICIO_RAPIDO.md)** - Seção "Instalar Dependências"  
→ **[README.md](README.md)** - Seção "Instalação"

### Quero adicionar uma playlist
→ **[INICIO_RAPIDO.md](INICIO_RAPIDO.md)** - Seção "Adicionar Primeira Playlist"  
→ **[README.md](README.md)** - Seção "Como Usar"

### Quero entender os formatos (MP3, MP4, WebM)
→ **[README.md](README.md)** - Seção "Formatos Suportados"  
→ **[FAQ.md](FAQ.md)** - "Qual formato usa menos espaço?"

### Quero trocar os ícones
→ **[COMO_TROCAR_ICONE.md](COMO_TROCAR_ICONE.md)** - Guia completo de personalização

### Quero gerar um executável (.exe)
→ **[README.md](README.md)** - Seção "Gerar Executável"

### Tenho um problema
→ **[TROUBLESHOOTING.md](TROUBLESHOOTING.md)** - Soluções detalhadas  
→ **[FAQ.md](FAQ.md)** - Perguntas frequentes

---

## 📁 Arquivos de Documentação

| Arquivo | Descrição | Quando Usar |
|---------|-----------|-------------|
| **[README.md](README.md)** | Documentação completa do projeto | Referência geral |
| **[INICIO_RAPIDO.md](INICIO_RAPIDO.md)** | Guia de 5 minutos | Primeira vez usando |
| **[FAQ.md](FAQ.md)** | Perguntas frequentes | Dúvidas rápidas |
| **[TROUBLESHOOTING.md](TROUBLESHOOTING.md)** | Soluções de problemas | Algo não funciona |
| **[COMO_TROCAR_ICONE.md](COMO_TROCAR_ICONE.md)** | Personalizar ícones | Customização |
| **[LICENSE](LICENSE)** | Licença MIT | Distribuição/modificação |

---

## 🔍 Busca Rápida por Tópico

### Instalação e Configuração
- **Instalar Python:** [README.md → Requisitos](README.md#-requisitos)
- **Instalar FFmpeg:** [README.md → Requisitos](README.md#2-ffmpeg-obrigatório-para-mp3-e-mp4)
- **Instalar dependências:** [INICIO_RAPIDO.md → Passo 1](INICIO_RAPIDO.md#1️⃣-instalar-dependências-2-minutos)
- **Primeira execução:** [INICIO_RAPIDO.md → Passo 2](INICIO_RAPIDO.md#2️⃣-iniciar-o-app-10-segundos)

### Uso Diário
- **Adicionar playlist:** [README.md → Como Usar](README.md#2-adicionar-uma-playlist)
- **Download manual:** [FAQ.md → Downloads](FAQ.md#-downloads)
- **Pausar monitoramento:** [README.md → Menu da Bandeja](README.md#4-menu-da-bandeja)
- **Mudar formato:** [FAQ.md → Configuração](FAQ.md#posso-ter-formatos-diferentes-para-cada-playlist)

### Problemas Comuns
- **FFmpeg not found:** [TROUBLESHOOTING.md → FFmpeg](TROUBLESHOOTING.md#-problemas-com-ffmpeg)
- **Download não inicia:** [TROUBLESHOOTING.md → Downloads](TROUBLESHOOTING.md#-downloads-ficam-em-0-ou-não-iniciam)
- **Ícone não aparece:** [TROUBLESHOOTING.md → Interface](TROUBLESHOOTING.md#-ícone-não-aparece-na-bandeja)
- **Download trava 99%:** [TROUBLESHOOTING.md → Downloads](TROUBLESHOOTING.md#-download-trava-em-99)

### Personalização
- **Trocar ícone bandeja:** [COMO_TROCAR_ICONE.md → Bandeja](COMO_TROCAR_ICONE.md#1️⃣-ícone-da-bandeja-system-tray-)
- **Trocar ícone janela:** [COMO_TROCAR_ICONE.md → Janela](COMO_TROCAR_ICONE.md#2️⃣-ícone-da-janela-barra-de-tarefas-)
- **Trocar ícone .exe:** [COMO_TROCAR_ICONE.md → Executável](COMO_TROCAR_ICONE.md#3️⃣-ícone-do-executável-exe-)

### Avançado
- **Estrutura do código:** [README.md → Estrutura](README.md#-estrutura-do-projeto)
- **Gerar executável:** [README.md → Gerar .exe](README.md#-gerar-executável-exe)
- **Configuração JSON:** [README.md → Configuração Avançada](README.md#-configuração-avançada)
- **Logs e debug:** [TROUBLESHOOTING.md → Logs](TROUBLESHOOTING.md#-logs-e-diagnóstico)

---

## 🎓 Tutoriais por Nível

### 🌱 Iniciante
1. [INICIO_RAPIDO.md](INICIO_RAPIDO.md) - Comece aqui
2. [README.md → Como Usar](README.md#-como-usar) - Uso básico
3. [FAQ.md → Casos de Uso](FAQ.md#-casos-de-uso) - Exemplos práticos

### 🌿 Intermediário
1. [README.md → Formatos](README.md#-formatos-suportados) - Entenda os formatos
2. [README.md → Configuração Avançada](README.md#-configuração-avançada) - Personalize
3. [FAQ.md → Organização](FAQ.md#-organização) - Organize seus downloads

### 🌳 Avançado
1. [README.md → Estrutura](README.md#-estrutura-do-projeto) - Entenda o código
2. [README.md → Gerar .exe](README.md#-gerar-executável-exe) - Distribua
3. [TROUBLESHOOTING.md → Logs](TROUBLESHOOTING.md#-logs-e-diagnóstico) - Debug

---

## 🆘 Precisa de Ajuda?

### Fluxograma de Ajuda

```
Tenho uma dúvida
    ├─ Sobre instalação? → INICIO_RAPIDO.md ou README.md (Instalação)
    ├─ Algo não funciona? → TROUBLESHOOTING.md
    ├─ Pergunta rápida? → FAQ.md
    ├─ Quero personalizar? → COMO_TROCAR_ICONE.md
    └─ Informação geral? → README.md
```

### Não Encontrou a Resposta?

1. Busque no FAQ: [FAQ.md](FAQ.md)
2. Veja Troubleshooting: [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
3. Leia os logs: `data/logs/senko_watcher.log`
4. Abra uma issue no GitHub

---

## 📄 Outros Arquivos Importantes

- **requirements.txt** - Lista de dependências Python
- **SenkoWatcher.spec** - Configuração do PyInstaller
- **build.bat** - Script para gerar .exe no Windows
- **.gitignore** - Arquivos ignorados pelo Git
- **LICENSE** - Licença MIT do projeto

---

## 🗺️ Mapa Mental

```
Senko Watcher
│
├─ 🚀 Começar
│  ├─ INICIO_RAPIDO.md (⏱️ 5 min)
│  └─ README.md (📚 completo)
│
├─ ❓ Perguntas
│  ├─ FAQ.md (respostas rápidas)
│  └─ TROUBLESHOOTING.md (problemas)
│
├─ 🎨 Personalizar
│  └─ COMO_TROCAR_ICONE.md
│
└─ 📜 Legal
   └─ LICENSE
```

---

## 🔖 Marcadores Úteis

Salve estes links para acesso rápido:

- 🆘 **Problema?** → [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
- ❓ **Dúvida?** → [FAQ.md](FAQ.md)
- 📖 **Referência?** → [README.md](README.md)
- ⚡ **Início?** → [INICIO_RAPIDO.md](INICIO_RAPIDO.md)

---

## 📊 Estatísticas da Documentação

- **Total de arquivos:** 6 documentos principais
- **Páginas:** ~50 páginas
- **Tópicos cobertos:** 100+
- **FAQs respondidas:** 40+
- **Problemas resolvidos:** 30+

---

## 🎯 Checklist de Leitura

Para aproveitar 100% do Senko Watcher:

- [ ] Li o INICIO_RAPIDO.md
- [ ] Instalei e testei o app
- [ ] Adicionei minha primeira playlist
- [ ] Entendi os formatos (MP3, MP4, WebM)
- [ ] Sei onde estão os logs
- [ ] Guardei este índice para referência

---

**🦊 Boa leitura e bom uso do Senko Watcher!**

_Última atualização: Fevereiro 2024_
