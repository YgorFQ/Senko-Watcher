# services/config_manager.py  --  Senko Watcher
# Manages data/config.json.
# Per-playlist download folder is MANDATORY -- no global fallback.
# Thread-safe reads and atomic writes.

import json
import os
import threading

_BASE        = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_CONFIG_PATH = os.path.join(_BASE, "data", "config.json")
_lock        = threading.Lock()

# Valid download format keys
VALID_FORMATS = ("mp3", "mp4", "webm-audio", "webm-video")

_DEFAULTS = {
    "playlists":                 [],
    "check_interval_seconds":    1800,
    "realtime_mode":             False,
    "realtime_interval_seconds": 60,
    "notifications_enabled":     True,
    "start_with_windows":        False,
    "start_minimized":           True,
    "max_retries":               2,
}


def _ensure_dir():
    os.makedirs(os.path.dirname(_CONFIG_PATH), exist_ok=True)


def _load_raw() -> dict:
    try:
        if os.path.exists(_CONFIG_PATH):
            with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _merge(raw: dict) -> dict:
    base = dict(_DEFAULTS)
    base.update(raw)
    return base


def _write(data: dict):
    _ensure_dir()
    tmp = _CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=True)
    os.replace(tmp, _CONFIG_PATH)


def load() -> dict:
    with _lock:
        return _merge(_load_raw())


def save(cfg: dict) -> None:
    with _lock:
        _write(cfg)


def get(key, default=None):
    return load().get(key, default)


def set_key(key, value) -> None:
    with _lock:
        data = _merge(_load_raw())
        data[key] = value
        _write(data)


def add_playlist(entry: dict) -> None:
    """Add playlist. download_folder must be set and non-empty."""
    with _lock:
        data = _merge(_load_raw())
        ids = {p["playlist_id"] for p in data.get("playlists", [])}
        if entry["playlist_id"] not in ids:
            if not entry.get("download_folder"):
                raise ValueError(
                    f"download_folder is required for playlist '{entry.get('name', '?')}'"
                )
            if entry.get("format") not in VALID_FORMATS:
                entry["format"] = "mp3"
            if "auto_download" not in entry:
                entry["auto_download"] = True
            data["playlists"].append(entry)
        _write(data)


def remove_playlist(playlist_id: str) -> None:
    with _lock:
        data = _merge(_load_raw())
        data["playlists"] = [
            p for p in data.get("playlists", []) if p["playlist_id"] != playlist_id
        ]
        _write(data)


def update_playlist(playlist_id: str, updates: dict) -> None:
    with _lock:
        data = _merge(_load_raw())
        for p in data.get("playlists", []):
            if p["playlist_id"] == playlist_id:
                p.update(updates)
        _write(data)


def get_playlist(playlist_id: str) -> dict:
    with _lock:
        data = _merge(_load_raw())
        for p in data.get("playlists", []):
            if p["playlist_id"] == playlist_id:
                return p
        return {}


# Kept for backward compat -- returns empty string (no global default)
def get_default_download_dir() -> str:
    return ""
