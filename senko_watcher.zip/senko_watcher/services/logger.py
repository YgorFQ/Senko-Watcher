# services/logger.py  --  Senko Watcher
import logging
import os
from logging.handlers import RotatingFileHandler

_BASE     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LOG_DIR  = os.path.join(_BASE, "data", "logs")
_LOG_FILE = os.path.join(_LOG_DIR, "app.log")
_logger   = None


def _init():
    global _logger
    if _logger:
        return
    os.makedirs(_LOG_DIR, exist_ok=True)
    _logger = logging.getLogger("SenkoWatcher")
    _logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    fh = RotatingFileHandler(_LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    _logger.addHandler(fh)


def get() -> logging.Logger:
    _init()
    return _logger

def debug(m):   get().debug(m)
def info(m):    get().info(m)
def warning(m): get().warning(m)
def error(m):   get().error(m)
def critical(m):get().critical(m)
