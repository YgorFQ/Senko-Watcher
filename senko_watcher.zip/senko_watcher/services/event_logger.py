# services/event_logger.py  --  Senko Watcher
# Append-only domain event log written to data/event_log.jsonl.
# Thread-safe.  Survives crashes.  Never rewrites history.

import json
import os
import threading
from datetime import datetime, timezone

_BASE     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LOG_PATH = os.path.join(_BASE, "data", "event_log.jsonl")
_lock     = threading.Lock()


def _ensure_dir():
    os.makedirs(os.path.dirname(_LOG_PATH), exist_ok=True)


def emit(event: str, payload: dict = None) -> None:
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event":     event,
    }
    if payload:
        record.update(payload)
    try:
        _ensure_dir()
        with _lock:
            with open(_LOG_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=True) + "\n")
    except Exception as exc:
        print(f"[EventLogger] WARNING: {event}: {exc}")


def read_all() -> list:
    try:
        _ensure_dir()
        with _lock:
            if not os.path.exists(_LOG_PATH):
                return []
            with open(_LOG_PATH, "r", encoding="utf-8") as f:
                out = []
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            out.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
                return out
    except Exception:
        return []
