# core/state_manager.py  --  Senko Watcher
# High-level command functions.  UI actions call these.  Never touch state directly.

import os
import threading

import app_state
import lifecycle_manager
import core.download_queue as dq
import core.watcher as watcher
import core.history_manager as history
import services.config_manager as config
import services.event_logger as ev
import services.logger as log


# ── Playlist CRUD ─────────────────────────────────────────────────────────────

def add_playlist(name: str, url: str, fmt: str = "mp3",
                 auto_download: bool = True, download_folder: str = "") -> str:
    """
    Add a new playlist.
    download_folder is REQUIRED -- raises ValueError if empty.
    Returns extracted playlist_id.
    """
    import re
    m = re.search(r"list=([A-Za-z0-9_-]+)", url)
    pid = m.group(1) if m else url.strip()

    if not download_folder or not download_folder.strip():
        raise ValueError(
            f"Pasta de download obrigatoria para a playlist '{name}'. "
            "Selecione uma pasta antes de continuar."
        )
    download_folder = download_folder.strip()

    entry = {
        "playlist_id":    pid,
        "name":           name,
        "url":            url,
        "format":         fmt,
        "auto_download":  auto_download,
        "download_folder": download_folder,
        "enabled":        True,
    }
    config.add_playlist(entry)

    playlists = app_state.get("playlists") or {}
    playlists[pid] = {
        "playlist_id":     pid,
        "name":            name,
        "url":             url,
        "format":          fmt,
        "auto_download":   auto_download,
        "download_folder": download_folder,
        "new_count":       0,
        "last_checked":    "",
        "video_count":     history.count_videos(pid),
        "offline_new_count": 0,
    }
    app_state.set_value("playlists", playlists)
    ev.emit("PLAYLIST_ADDED", {"playlist_id": pid, "name": name})
    log.info(f"Playlist added: {name} ({pid})")
    return pid


def remove_playlist(playlist_id: str) -> None:
    config.remove_playlist(playlist_id)
    playlists = app_state.get("playlists") or {}
    playlists.pop(playlist_id, None)
    app_state.update({
        "playlists":       playlists,
        "total_new_songs": sum(p.get("new_count", 0) for p in playlists.values()),
    })
    ev.emit("PLAYLIST_REMOVED", {"playlist_id": playlist_id})


def update_playlist_format(playlist_id: str, fmt: str) -> None:
    config.update_playlist(playlist_id, {"format": fmt})
    playlists = app_state.get("playlists") or {}
    if playlist_id in playlists:
        playlists[playlist_id]["format"] = fmt
        app_state.set_value("playlists", playlists)
    ev.emit("PLAYLIST_FORMAT_CHANGED", {"playlist_id": playlist_id, "format": fmt})


def update_playlist_folder(playlist_id: str, folder: str) -> None:
    """Change the download folder for a specific playlist."""
    if not folder:
        return
    config.update_playlist(playlist_id, {"download_folder": folder})
    playlists = app_state.get("playlists") or {}
    if playlist_id in playlists:
        playlists[playlist_id]["download_folder"] = folder
        app_state.set_value("playlists", playlists)
    ev.emit("PLAYLIST_FOLDER_CHANGED", {"playlist_id": playlist_id, "folder": folder})
    log.info(f"Download folder updated for {playlist_id}: {folder}")


def update_auto_download(playlist_id: str, enabled: bool) -> None:
    """Toggle auto-download for a playlist."""
    config.update_playlist(playlist_id, {"auto_download": enabled})
    playlists = app_state.get("playlists") or {}
    if playlist_id in playlists:
        playlists[playlist_id]["auto_download"] = enabled
        app_state.set_value("playlists", playlists)
    ev.emit("PLAYLIST_AUTO_DOWNLOAD_CHANGED", {"playlist_id": playlist_id, "enabled": enabled})


def clear_new_count(playlist_id: str) -> None:
    playlists = app_state.get("playlists") or {}
    if playlist_id in playlists:
        playlists[playlist_id]["new_count"] = 0
        app_state.update({
            "playlists":       playlists,
            "total_new_songs": sum(p.get("new_count", 0) for p in playlists.values()),
        })


# ── Download commands ─────────────────────────────────────────────────────────

def queue_videos_now(playlist_id: str, video_ids: list, fmt: str, folder: str = "") -> int:
    """
    Immediately queue selected videos.
    folder is taken from the playlist config if not explicitly provided.
    Returns number actually queued.
    Raises ValueError if no folder is configured for the playlist.
    """
    # Always resolve folder from config -- never trust caller blindly
    pcfg   = config.get_playlist(playlist_id)
    folder = (pcfg.get("download_folder") or folder or "").strip()
    fmt    = fmt or pcfg.get("format", "mp3")

    if not folder:
        raise ValueError(
            f"No download folder configured for playlist '{playlist_id}'. "
            "Set a folder in the playlist window before downloading."
        )

    videos = history.get_playlist_videos(playlist_id)
    queued = 0
    for vid_id in video_ids:
        v = videos.get(vid_id)
        if not v:
            continue
        job = {
            "video_id":        vid_id,
            "playlist_id":     playlist_id,
            "title":           v.get("title", vid_id),
            "url":             v.get("url", ""),
            "format":          fmt,
            "download_folder": folder,
        }
        if dq.push(job):
            ev.emit("DOWNLOAD_QUEUED", {
                "playlist_id": playlist_id,
                "video_id":    vid_id,
                "title":       v.get("title", ""),
                "manual":      True,
                "folder":      folder,
            })
            queued += 1

    app_state.set_value("download_queue_size", dq.size())
    if queued:
        app_state.set_value("status_message", f"Queued {queued} song(s) -> {folder}")
    return queued


# ── App-level commands ────────────────────────────────────────────────────────

def pause() -> None:
    if lifecycle_manager.is_running():
        lifecycle_manager.transition("PAUSED")
        app_state.set_value("status_message", "Monitoring paused.")
        ev.emit("APP_PAUSED")


def resume() -> None:
    if lifecycle_manager.is_paused():
        lifecycle_manager.transition("RUNNING")
        app_state.set_value("status_message", "Monitoring resumed.")
        ev.emit("APP_RESUMED")
        watcher.trigger_check_now()


def set_realtime_mode(enabled: bool, interval_seconds: int = 60) -> None:
    """Enable or disable real-time monitoring mode."""
    import services.config_manager as _cfg
    _cfg.set_key("realtime_mode", enabled)
    _cfg.set_key("realtime_interval_seconds", interval_seconds)
    app_state.update({
        "realtime_mode":     enabled,
        "realtime_interval": interval_seconds,
    })
    watcher.trigger_check_now()
    ev.emit("REALTIME_MODE_CHANGED", {"enabled": enabled, "interval": interval_seconds})
    log.info(f"Real-time mode {'enabled' if enabled else 'disabled'} (interval={interval_seconds}s)")


def check_now() -> None:
    watcher.trigger_check_now()
    app_state.set_value("status_message", "Manual check triggered...")


def sync_history(playlist_id: str) -> None:
    def _run():
        ev.emit("HISTORY_SYNC_STARTED", {"playlist_id": playlist_id})
        app_state.set_value("status_message", "Syncing history...")
        watcher.sync_one(playlist_id)
        ev.emit("HISTORY_SYNC_DONE", {"playlist_id": playlist_id})
        app_state.set_value("status_message", "History sync complete.")
    threading.Thread(target=_run, daemon=True, name="HistorySync").start()


# ── Bootstrap ─────────────────────────────────────────────────────────────────

def load_playlists_into_state() -> None:
    cfg = config.load()
    playlists = {}
    for p in cfg.get("playlists", []):
        pid = p["playlist_id"]
        playlists[pid] = {
            "playlist_id":     pid,
            "name":            p.get("name", pid),
            "url":             p.get("url", ""),
            "format":          p.get("format", "mp3"),
            "auto_download":   p.get("auto_download", True),
            "download_folder": p.get("download_folder", ""),
            "new_count":       0,
            "last_checked":    "",
            "video_count":     history.count_videos(pid),
            "offline_new_count": 0,
        }
    app_state.update({
        "playlists":             playlists,
        "notifications_enabled": cfg.get("notifications_enabled", True),
        "startup_minimized":     cfg.get("start_minimized", True),
        "realtime_mode":         cfg.get("realtime_mode", False),
        "realtime_interval":     cfg.get("realtime_interval_seconds", 60),
    })
