# core/history_manager.py  --  Senko Watcher
# Append-only video history.  First scan never auto-downloads.
# Stores full datetime (DD/MM/YYYY HH:MM:SS) for each video.
# Atomic writes prevent corruption.
#
# Structure:
# {
#   "playlist_id": {
#     "videos": {
#       "video_id": {
#         "title":      str,
#         "url":        str,
#         "first_seen": "DD/MM/YYYY HH:MM:SS",
#         "downloaded": bool,
#       }
#     }
#   }
# }

import json
import os
import threading
from datetime import datetime

_BASE         = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_HISTORY_PATH = os.path.join(_BASE, "data", "history.json")
_lock         = threading.RLock()


def _ensure_dir():
    os.makedirs(os.path.dirname(_HISTORY_PATH), exist_ok=True)


def _load_raw() -> dict:
    try:
        if os.path.exists(_HISTORY_PATH):
            with open(_HISTORY_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _save_raw(data: dict) -> None:
    _ensure_dir()
    tmp = _HISTORY_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=True)
    os.replace(tmp, _HISTORY_PATH)


def _now_str() -> str:
    """Full datetime string: DD/MM/YYYY HH:MM:SS"""
    return datetime.now().strftime("%d/%m/%Y %H:%M:%S")


def load() -> dict:
    with _lock:
        return _load_raw()


def get_playlist_videos(playlist_id: str) -> dict:
    with _lock:
        return _load_raw().get(playlist_id, {}).get("videos", {})


def get_known_ids(playlist_id: str) -> set:
    return set(get_playlist_videos(playlist_id).keys())


def add_videos(playlist_id: str, new_videos: list) -> list:
    """
    Append new videos to history.
    Returns list of truly-new video_ids.
    """
    with _lock:
        data = _load_raw()
        if playlist_id not in data:
            data[playlist_id] = {"videos": {}}
        existing = data[playlist_id]["videos"]
        now = _now_str()
        truly_new = []
        for v in new_videos:
            vid = v["video_id"]
            if vid not in existing:
                existing[vid] = {
                    "title":      v.get("title", "Unknown"),
                    "url":        v.get("url", ""),
                    "first_seen": now,
                    "downloaded": False,
                }
                truly_new.append(vid)
        _save_raw(data)
        return truly_new


def mark_downloaded(playlist_id: str, video_id: str) -> None:
    with _lock:
        data = _load_raw()
        try:
            data[playlist_id]["videos"][video_id]["downloaded"] = True
            _save_raw(data)
        except KeyError:
            pass


def is_first_scan(playlist_id: str) -> bool:
    with _lock:
        return playlist_id not in _load_raw()


def count_videos(playlist_id: str) -> int:
    return len(get_playlist_videos(playlist_id))


def count_not_downloaded(playlist_id: str) -> int:
    return sum(
        1 for v in get_playlist_videos(playlist_id).values()
        if not v.get("downloaded", False)
    )
