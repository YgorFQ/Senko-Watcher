# core/offline_detector.py  --  Senko Watcher
# Detects new videos added to playlists while the app was not running.
# Strategy:
#   1. On startup, for each playlist, check which video_ids in history
#      are marked as "not downloaded".
#   2. Also scan the download folder for audio/video files present there;
#      if a file matches a history title (fuzzy), mark it as downloaded.
#   3. Report any history videos not yet downloaded as "pending offline".
#
# This gives users a summary of what they may have missed.

import os
import services.logger as log
import services.event_logger as ev
import core.history_manager as history
import services.config_manager as config
import app_state


# Audio/video file extensions to look for
_AUDIO_EXTS = {".mp3", ".webm", ".m4a", ".opus", ".ogg", ".flac", ".wav", ".aac"}


def _get_files_in_folder(folder: str) -> set:
    """Return set of lowercase basenames (without extension) of all audio files."""
    if not folder or not os.path.isdir(folder):
        return set()
    result = set()
    try:
        for fname in os.listdir(folder):
            root, ext = os.path.splitext(fname)
            if ext.lower() in _AUDIO_EXTS:
                result.add(root.lower().strip())
    except PermissionError:
        pass
    return result


def _title_in_files(title: str, file_basenames: set) -> bool:
    """Check if a video title approximately matches a filename."""
    # Sanitize title the same way yt-dlp does (rough approximation)
    safe_title = title.lower().strip()
    # Remove common special chars
    for ch in r'\/:*?"<>|':
        safe_title = safe_title.replace(ch, "_")
    safe_title = safe_title[:80]  # yt-dlp clips long names
    return safe_title in file_basenames


def run_startup_detection() -> dict:
    """
    Scan all playlists for pending (not downloaded) videos.
    Cross-reference with local folder to auto-mark already-present files.

    Returns:
        { playlist_id: [video_id, ...] }   -- videos not yet downloaded
    """
    cfg_list = config.get("playlists") or []
    result   = {}

    for pcfg in cfg_list:
        pid    = pcfg["playlist_id"]
        folder = (pcfg.get("download_folder") or "").strip()
        videos = history.get_playlist_videos(pid)

        if not videos:
            continue

        # Skip if no folder configured -- can't auto-detect downloads
        if not folder or not os.path.isdir(folder):
            pending = [
                vid_id for vid_id, vdata in videos.items()
                if not vdata.get("downloaded", False)
            ]
            if pending:
                result[pid] = pending
            continue

        # Files already in the download folder
        local_files = _get_files_in_folder(folder)

        pending = []
        for vid_id, vdata in videos.items():
            if vdata.get("downloaded", False):
                continue
            title = vdata.get("title", "")
            # If the file is already on disk, auto-mark downloaded
            if local_files and _title_in_files(title, local_files):
                history.mark_downloaded(pid, vid_id)
                ev.emit("OFFLINE_FILE_DETECTED", {
                    "playlist_id": pid,
                    "video_id":    vid_id,
                    "title":       title,
                })
                log.info(f"Auto-marked as downloaded (file found): {title}")
            else:
                pending.append(vid_id)

        if pending:
            result[pid] = pending
            log.info(f"Offline pending for {pid}: {len(pending)} songs")
            ev.emit("OFFLINE_PENDING_DETECTED", {
                "playlist_id": pid,
                "count":       len(pending),
            })

    return result


def update_state_with_offline(pending: dict) -> None:
    """Push offline detection results into AppState."""
    app_state.set_value("offline_new", pending)
    total = sum(len(v) for v in pending.values())
    app_state.set_value("total_offline_new", total)

    # Also update per-playlist offline_new_count
    playlists = app_state.get("playlists") or {}
    for pid, vids in pending.items():
        if pid in playlists:
            playlists[pid]["offline_new_count"] = len(vids)
    app_state.set_value("playlists", playlists)
