# core/download_queue.py  --  Senko Watcher
# Thread-safe download queue with deduplication via active_jobs set.

import queue
import threading

_queue       = queue.Queue()
_active_jobs = set()   # video_ids currently queued or downloading
_lock        = threading.Lock()


def push(job: dict) -> bool:
    """
    Enqueue a download job.  Returns True if queued, False if duplicate.

    Job fields:
      video_id, playlist_id, title, url, format, download_folder
    """
    vid = job.get("video_id", "")
    with _lock:
        if vid in _active_jobs:
            return False
        _active_jobs.add(vid)
    _queue.put(job)
    return True


def pop(timeout: float = 1.0):
    """Pull next job.  Returns None on timeout."""
    try:
        return _queue.get(timeout=timeout)
    except queue.Empty:
        return None


def release(video_id: str) -> None:
    """Mark video done -- remove from active set."""
    with _lock:
        _active_jobs.discard(video_id)


def size() -> int:
    return _queue.qsize()


def active_count() -> int:
    with _lock:
        return len(_active_jobs)


def is_queued(video_id: str) -> bool:
    with _lock:
        return video_id in _active_jobs


def clear() -> None:
    with _lock:
        while not _queue.empty():
            try:
                _queue.get_nowait()
            except queue.Empty:
                break
        _active_jobs.clear()
