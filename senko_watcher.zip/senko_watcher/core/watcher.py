# core/watcher.py  --  Senko Watcher
# Periodic playlist checker thread.
# First scan: records snapshot, no auto-download.
# Subsequent scans: queues new videos if auto_download enabled.

import threading
import time
from datetime import datetime

import app_state
import lifecycle_manager
import core.download_queue as dq
import core.history_manager as history
import services.logger as log
import services.event_logger as ev
import services.config_manager as config

_thread: threading.Thread = None
_stop_event    = threading.Event()
_check_now_evt = threading.Event()


def _now_str() -> str:
    return datetime.now().strftime("%d/%m/%Y %H:%M")


def _fetch_playlist_videos(url: str) -> list:
    """Fetch video list via yt-dlp.  Returns [] on error."""
    try:
        import yt_dlp
    except ImportError:
        log.error("yt-dlp not installed.")
        return []

    opts = {
        "quiet":        True,
        "extract_flat": True,
        "no_warnings":  True,
        "ignoreerrors": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                return []
            videos = []
            for e in (info.get("entries") or []):
                if not e:
                    continue
                vid_id = e.get("id") or ""
                if not vid_id:
                    continue
                videos.append({
                    "video_id": vid_id,
                    "title":    e.get("title", vid_id),
                    "url":      f"https://www.youtube.com/watch?v={vid_id}",
                })
            return videos
    except Exception as exc:
        log.error(f"Fetch error for {url}: {exc}")
        return []


def _check_one_playlist(pcfg: dict) -> None:
    pid          = pcfg["playlist_id"]
    url          = pcfg["url"]
    fmt          = pcfg.get("format", "mp3")
    name         = pcfg.get("name", pid)
    auto_dl      = pcfg.get("auto_download", True)
    dl_folder    = pcfg.get("download_folder", "")
    is_first     = history.is_first_scan(pid)

    log.info(f"Checking: {name}")
    ev.emit("PLAYLIST_CHECK_STARTED", {"playlist_id": pid, "name": name})
    app_state.set_value("status_message", f"Checking: {name}...")

    videos = _fetch_playlist_videos(url)
    if not videos:
        log.warning(f"No videos found: {name}")
        ev.emit("PLAYLIST_CHECK_EMPTY", {"playlist_id": pid})
        _update_playlist_state(pcfg, 0, history.count_videos(pid))
        return

    new_ids = history.add_videos(pid, videos)
    total   = history.count_videos(pid)
    now     = _now_str()

    if is_first:
        log.info(f"First scan {name}: {len(videos)} videos recorded.")
        ev.emit("PLAYLIST_SYNCED", {"playlist_id": pid, "total": len(videos), "new": 0, "first_scan": True})
        _update_playlist_state(pcfg, 0, total, now)
        return

    # Queue new videos if auto_download is on
    if new_ids and auto_dl:
        if not dl_folder:
            ev.emit("PLAYLIST_DOWNLOAD_SKIPPED", {
                "playlist_id": pid,
                "reason": "no download_folder configured",
            })
            log.warning(f"Skipping auto-download for '{name}': no download_folder set.")
        else:
            vid_map = {v["video_id"]: v for v in videos}
            for vid_id in new_ids:
                v = vid_map.get(vid_id)
                if not v:
                    continue
                ev.emit("NEW_VIDEO_DETECTED", {
                    "playlist_id": pid, "video_id": vid_id, "title": v["title"],
                })
                queued = dq.push({
                    "video_id":        vid_id,
                    "playlist_id":     pid,
                    "title":           v["title"],
                    "url":             v["url"],
                    "format":          fmt,
                    "download_folder": dl_folder,
                })
                if queued:
                    ev.emit("DOWNLOAD_QUEUED", {
                        "playlist_id": pid,
                        "video_id":    vid_id,
                        "folder":      dl_folder,
                    })
    elif new_ids:
        # Auto-download disabled: report as pending
        ev.emit("NEW_VIDEOS_PENDING", {"playlist_id": pid, "count": len(new_ids)})

    _update_playlist_state(pcfg, len(new_ids), total, now)
    ev.emit("PLAYLIST_SYNCED", {"playlist_id": pid, "total": total, "new": len(new_ids)})


def _update_playlist_state(pcfg: dict, new_count: int, total: int, now: str = "") -> None:
    pid   = pcfg["playlist_id"]
    playlists = app_state.get("playlists") or {}
    existing_new = 0
    if pid in playlists:
        existing_new = playlists[pid].get("new_count", 0)

    playlists[pid] = {
        "playlist_id":        pid,
        "name":               pcfg.get("name", pid),
        "url":                pcfg.get("url", ""),
        "format":             pcfg.get("format", "mp3"),
        "auto_download":      pcfg.get("auto_download", True),
        "download_folder":    pcfg.get("download_folder", ""),
        "new_count":          existing_new + new_count,
        "last_checked":       now or _now_str(),
        "video_count":        total,
        "offline_new_count":  playlists.get(pid, {}).get("offline_new_count", 0),
    }
    total_new = sum(p.get("new_count", 0) for p in playlists.values())
    app_state.update({
        "playlists":          playlists,
        "total_new_songs":    total_new,
        "last_check_time":    _now_str(),
        "download_queue_size": dq.size(),
    })


def _run_all_playlists() -> None:
    if not lifecycle_manager.is_running():
        return
    for pcfg in (config.get("playlists") or []):
        if _stop_event.is_set():
            break
        if not pcfg.get("enabled", True):
            continue
        try:
            _check_one_playlist(pcfg)
        except Exception as exc:
            log.error(f"Error checking {pcfg.get('playlist_id')}: {exc}")
            ev.emit("PLAYLIST_CHECK_ERROR", {
                "playlist_id": pcfg.get("playlist_id", "?"),
                "error": str(exc),
            })


def _watcher_loop():
    log.info("Watcher started.")
    ev.emit("WATCHER_STARTED")
    while not _stop_event.is_set():
        if lifecycle_manager.is_shutting_down():
            break
        _run_all_playlists()
        realtime = app_state.get("realtime_mode", False)
        if realtime:
            interval = app_state.get("realtime_interval", 60)
            app_state.set_value("status_message", f"Real-time mode -- next check in {interval}s.")
        else:
            interval = config.get("check_interval_seconds", 1800)
            mins = interval // 60
            app_state.set_value("status_message", f"Idle. Next check in {mins} min.")
        log.info(f"Next check in {interval}s (realtime={app_state.get('realtime_mode', False)}).")
        _check_now_evt.wait(timeout=interval)
        _check_now_evt.clear()
    ev.emit("WATCHER_STOPPED")
    log.info("Watcher stopped.")


def sync_one(playlist_id: str) -> None:
    """Sync a single playlist (called from history sync button)."""
    for pcfg in (config.get("playlists") or []):
        if pcfg["playlist_id"] == playlist_id:
            try:
                _check_one_playlist(pcfg)
            except Exception as exc:
                log.error(f"Sync error {playlist_id}: {exc}")
            return


def trigger_check_now() -> None:
    _check_now_evt.set()


def start() -> None:
    global _thread
    _stop_event.clear()
    _thread = threading.Thread(target=_watcher_loop, name="Watcher", daemon=True)
    _thread.start()


def stop() -> None:
    _stop_event.set()
    _check_now_evt.set()
    if _thread and _thread.is_alive():
        _thread.join(timeout=10)
