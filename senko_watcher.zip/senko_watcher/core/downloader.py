# core/downloader.py  --  Senko Watcher
# Background download worker.
#
# Supported formats:
#   mp3        -- audio only, converted to mp3 via ffmpeg
#   mp4        -- best video+audio merged into mp4
#   webm-audio -- audio only, native webm (no ffmpeg needed)
#   webm-video -- best video+audio merged into webm
#
# STRICT: download_folder MUST be set in each job. No fallback.

import os
import threading

import app_state
import lifecycle_manager
import core.download_queue as dq
import core.history_manager as history
import services.logger as log
import services.event_logger as ev

MAX_RETRIES = 2

_stop_event = threading.Event()
_thread: threading.Thread = None


def _resolve_folder(job: dict) -> str:
    """
    Return the absolute download folder for this job.
    Raises RuntimeError if folder is missing or invalid.
    """
    folder = (job.get("download_folder") or "").strip()
    if not folder:
        raise RuntimeError(
            f"No download_folder set for playlist '{job.get('playlist_id', '?')}'. "
            "Set a download folder in the playlist settings before downloading."
        )
    if not os.path.isabs(folder):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        folder = os.path.join(base, folder)
    try:
        os.makedirs(folder, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(f"Cannot create download folder '{folder}': {exc}")
    return folder


def _make_progress_hook(video_id: str):
    def hook(d: dict):
        status = d.get("status", "")
        if status == "downloading":
            total      = d.get("total_bytes") or d.get("total_bytes_estimate", 0)
            downloaded = d.get("downloaded_bytes", 0)
            if total and total > 0:
                pct = min(99.0, (downloaded / total) * 100)
            else:
                pct_str = d.get("_percent_str", "0%").strip().replace("%", "")
                try:
                    pct = float(pct_str)
                except ValueError:
                    pct = 0.0
            progress = app_state.get("download_progress") or {}
            progress[video_id] = pct
            app_state.set_value("download_progress", progress)
        elif status == "finished":
            progress = app_state.get("download_progress") or {}
            progress[video_id] = 100.0
            app_state.set_value("download_progress", progress)
    return hook


def _build_ydl_opts(fmt: str, output_dir: str, video_id: str) -> dict:
    """
    Return yt-dlp options dict for the given format.

    fmt values:
      mp3        -> best audio, postprocess to mp3 (requires ffmpeg)
      mp4        -> best video+audio merged into mp4 (requires ffmpeg)
      webm-audio -> best audio in webm container (no ffmpeg required)
      webm-video -> best video+audio in webm container (no ffmpeg required)
    """
    outtmpl = os.path.join(output_dir, "%(title)s.%(ext)s")
    base = {
        "outtmpl":        outtmpl,
        "quiet":          True,
        "no_warnings":    True,
        "ignoreerrors":   False,
        "retries":        0,
        "progress_hooks": [_make_progress_hook(video_id)],
    }

    if fmt == "mp3":
        base["format"] = "bestaudio/best"
        base["postprocessors"] = [{
            "key":              "FFmpegExtractAudio",
            "preferredcodec":   "mp3",
            "preferredquality": "192",
        }]

    elif fmt == "mp4":
        # bestvideo+bestaudio merged into mp4 via ffmpeg
        base["format"] = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best"
        base["merge_output_format"] = "mp4"
        # No postprocessor needed - merge_output_format handles the conversion

    elif fmt == "webm-audio":
        # Audio-only webm -- no ffmpeg needed
        base["format"] = "bestaudio[ext=webm]/bestaudio"
        # No postprocessor: yt-dlp already downloads webm audio natively

    elif fmt == "webm-video":
        # Video+audio in webm -- prefer native webm streams
        base["format"] = (
            "bestvideo[ext=webm]+bestaudio[ext=webm]/"
            "bestvideo+bestaudio/best"
        )
        base["merge_output_format"] = "webm"

    else:
        # Unknown format -- fall back to best available audio as mp3
        log.warning(f"Unknown format '{fmt}', falling back to mp3.")
        base["format"] = "bestaudio/best"
        base["postprocessors"] = [{
            "key":              "FFmpegExtractAudio",
            "preferredcodec":   "mp3",
            "preferredquality": "192",
        }]

    return base


def _do_download(job: dict, attempt: int) -> bool:
    """Single download attempt. Returns True on success."""
    try:
        import yt_dlp
    except ImportError:
        ev.emit("DOWNLOAD_FAILED", {
            "video_id":    job["video_id"],
            "playlist_id": job["playlist_id"],
            "reason":      "yt-dlp not installed",
        })
        log.error("yt-dlp is not installed.")
        return False

    video_id = job["video_id"]
    url      = job["url"]
    fmt      = job.get("format", "mp3")
    title    = job.get("title", video_id)

    try:
        output_dir = _resolve_folder(job)
    except RuntimeError as exc:
        log.error(str(exc))
        ev.emit("DOWNLOAD_FAILED", {
            "video_id":    video_id,
            "playlist_id": job["playlist_id"],
            "reason":      str(exc),
        })
        app_state.set_value("status_message", f"ERROR: {exc}")
        return False

    log.info(f"Download [{fmt}] -> {output_dir} | '{title}' (attempt {attempt+1})")
    ev.emit("DOWNLOAD_STARTED", {
        "video_id":    video_id,
        "playlist_id": job["playlist_id"],
        "title":       title,
        "format":      fmt,
        "attempt":     attempt,
        "folder":      output_dir,
    })

    app_state.update({
        "active_download":       video_id,
        "currently_downloading": title[:70],
        "status_message":        f"Downloading [{fmt}]: {title[:50]}...",
    })

    ydl_opts = _build_ydl_opts(fmt, output_dir, video_id)

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        return True
    except Exception as exc:
        log.error(f"yt-dlp error for {video_id}: {exc}")
        return False


def _notify(title: str) -> None:
    try:
        from plyer import notification
        notification.notify(
            title="Senko Watcher",
            message=f"Downloaded: {title[:80]}",
            app_name="Senko Watcher",
            timeout=6,
        )
    except Exception:
        pass


def _worker_loop():
    log.info("Download worker started.")
    ev.emit("DOWNLOAD_WORKER_STARTED")

    while not _stop_event.is_set():
        if lifecycle_manager.is_shutting_down():
            break

        job = dq.pop(timeout=1.0)
        if job is None:
            app_state.update({
                "download_queue_size":   dq.size(),
                "active_download":       None,
                "currently_downloading": "",
            })
            continue

        video_id = job["video_id"]
        success  = False

        for attempt in range(MAX_RETRIES + 1):
            if _stop_event.is_set():
                break
            success = _do_download(job, attempt)
            if success:
                break
            if attempt < MAX_RETRIES:
                log.warning(f"Retry {attempt+1}/{MAX_RETRIES} for {video_id}")

        # Clear progress
        progress = app_state.get("download_progress") or {}
        progress.pop(video_id, None)
        app_state.set_value("download_progress", progress)

        if success:
            ev.emit("DOWNLOAD_FINISHED", {
                "video_id":    video_id,
                "playlist_id": job["playlist_id"],
                "title":       job.get("title", ""),
                "folder":      job.get("download_folder", ""),
            })
            history.mark_downloaded(job["playlist_id"], video_id)
            app_state.set_value("status_message", f"Done: {job.get('title', '')[:60]}")
            if app_state.get("notifications_enabled"):
                _notify(job.get("title", ""))
        else:
            ev.emit("DOWNLOAD_FAILED", {
                "video_id":    video_id,
                "playlist_id": job["playlist_id"],
                "title":       job.get("title", ""),
            })
            app_state.set_value("status_message", f"Failed: {job.get('title', '')[:60]}")

        dq.release(video_id)
        app_state.update({
            "download_queue_size":   dq.size(),
            "active_download":       None,
            "currently_downloading": "",
        })

    ev.emit("DOWNLOAD_WORKER_STOPPED")
    log.info("Download worker stopped.")


def start() -> None:
    global _thread
    _stop_event.clear()
    _thread = threading.Thread(target=_worker_loop, name="DownloadWorker", daemon=True)
    _thread.start()


def stop() -> None:
    _stop_event.set()
    if _thread and _thread.is_alive():
        _thread.join(timeout=5)
