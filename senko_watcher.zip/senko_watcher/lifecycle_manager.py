# lifecycle_manager.py  --  Senko Watcher
# Controls all lifecycle transitions.  ONLY this module may change "lifecycle".
#
# Valid transitions:
#   BOOTING       -> RUNNING
#   RUNNING       -> PAUSED | SHUTTING_DOWN
#   PAUSED        -> RUNNING | SHUTTING_DOWN
#   SHUTTING_DOWN -> STOPPED

import app_state
from services.event_logger import emit

VALID_TRANSITIONS = {
    "BOOTING":       {"RUNNING"},
    "RUNNING":       {"PAUSED", "SHUTTING_DOWN"},
    "PAUSED":        {"RUNNING", "SHUTTING_DOWN"},
    "SHUTTING_DOWN": {"STOPPED"},
    "STOPPED":       set(),
}


class LifecycleError(Exception):
    pass


def current() -> str:
    return app_state.get("lifecycle", "BOOTING")


def transition(new_state: str) -> None:
    old = current()
    if new_state not in VALID_TRANSITIONS.get(old, set()):
        raise LifecycleError(f"Invalid transition: {old} -> {new_state}")
    app_state.set_value("lifecycle", new_state)
    emit(f"LIFECYCLE_{new_state}", {"from": old, "to": new_state})


def is_running()      -> bool: return current() == "RUNNING"
def is_paused()       -> bool: return current() == "PAUSED"
def is_active()       -> bool: return current() in ("RUNNING", "PAUSED")
def is_shutting_down()-> bool: return current() in ("SHUTTING_DOWN", "STOPPED")
